# blink - two FreeRTOS tasks sharing one LED

Sample project for the **RobotIT lab board** (ESP32-S3). It is intentionally
small: one `main.c`, two tasks, one mutex. Read this file once, then read
[main/main.c](main/main.c) - it is commented line by line.

| | |
| --- | --- |
| Target | ESP32-S3 |
| Framework | ESP-IDF v6.0 (v5.x should also work) |
| Hardware | RobotIT lab board, status LED on GPIO2 |
| Build system | CMake / `idf.py` |

## What the sample does

`app_main()` configures the status LED and starts two tasks:

| Task | Priority | Period | Job |
| --- | --- | --- | --- |
| `blink_task` | 2 (higher) | 500 ms | Toggles the LED and updates `s_state.led_on` |
| `monitoring_task` | 1 | 500 ms | Reads `s_state.led_on` and logs it |

Both tasks touch the same variable, so that variable is shared state. FreeRTOS
may switch tasks between almost any two instructions, which means that without
protection this can happen:

1. `blink_task` reads `led_on` (false) and starts writing `true`.
2. The tick interrupt preempts it; `monitoring_task` runs and reads `led_on`.
3. `monitoring_task` reads the *old* value, so its log line contradicts reality.

The sample prevents this with a **mutex**:

```c
if (xSemaphoreTake(s_state.mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
    /* only one task at a time gets here */
    xSemaphoreGive(s_state.mutex);
}
```

Rule of thumb: *every* read and *every* write of shared data happens between
`xSemaphoreTake()` and `xSemaphoreGive()`.

## Expected output

```text
I (312) blink: starting the blink sample
I (322) blink: [blink]   LED state: OFF
I (332) blink: [monitor] LED state: OFF
I (342) blink: tasks started, main task is finished
I (822) blink: [blink]   LED state: ON
I (832) blink: [monitor] LED state: ON
I (1322) blink: [blink]   LED state: OFF
I (1332) blink: [monitor] LED state: OFF
```

The two lines of each pair agree, and the LED is lit for 500 ms and dark for
500 ms. The number in parentheses is milliseconds since boot; your timestamps will
differ slightly.

Two details worth noticing, because they teach how the scheduler works:

* `[blink]` shows up before `tasks started`: `blink_task` has a higher priority
  than the `main` task (which sits at priority 1), so FreeRTOS runs it as soon as
  `xTaskCreate()` returns.
* `[monitor]` has the *same* priority as `main`, so it starts either before or
  after the last log line of `app_main()` - both orders are correct.

## Build, flash, monitor

```bash
idf.py build
idf.py -p COM18 flash monitor             # Linux/macOS: -p /dev/ttyACM0
```

Press `Ctrl-]` to leave the monitor. In VS Code you can use the ESP-IDF buttons in
the status bar instead of typing the commands.

The target does not have to be selected by hand: `sdkconfig.defaults` already
contains `CONFIG_IDF_TARGET="esp32s3"`, so `idf.py build` picks up ESP32-S3 on a
fresh checkout and configures `sdkconfig` from these defaults.

## Things to try

Each item is a small change to [main/main.c](main/main.c) plus
`idf.py build flash monitor`. Delete `sdkconfig` if you want to start from a
known-good state again.

1. **Remove the mutex.** Delete every `xSemaphoreTake()`/`xSemaphoreGive()` call
   but keep the task bodies. The sample still mostly works, because toggling a
   variable is a single instruction - which is exactly why this class of bug is so
   dangerous. To provoke it, make the critical section longer: read the value into
   a local variable, `vTaskDelay()` for ~100 ms, then write it back and log it.
   The two tasks will start reporting different states.
2. **Remove the timeout.** Replace `pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)` with
   `portMAX_DELAY`. A task that never gives the mutex back now hangs both tasks -
   which is why the sample prefers to log a warning and skip.
3. **Forget one `xSemaphoreGive()`.** Delete it from `blink_task`. After a single
   iteration the monitoring task starves and prints the "mutex busy" warning on
   every round.
4. **Change the priorities.** Swap `BLINK_TASK_PRIORITY` and
   `MONITOR_TASK_PRIORITY`. Nothing breaks - priorities decide *who runs first*,
   not whether the data stays consistent. That is the whole point of the mutex.
5. **Share more data.** Add a `uint32_t blink_count;` to `shared_state_t`,
   increment it in `blink_task` and log it from `monitoring_task`. Touch it only
   while holding the mutex.
6. **Use a queue instead.** Replace the mutex + variable with a one-element
   FreeRTOS queue (`xQueueCreate(1, sizeof(bool))`) and compare how the code reads.

## Files

| Path | Purpose |
| --- | --- |
| [main/main.c](main/main.c) | The complete sample: shared state, two tasks, `app_main()` |
| [main/CMakeLists.txt](main/CMakeLists.txt) | Registers `main.c` and requires `robot_hal` |
| [main/idf_component.yml](main/idf_component.yml) | Component-manager manifest (no dependencies) |
| [sdkconfig.defaults](sdkconfig.defaults) | Board defaults: target, flash size, log level |
| [robot_hal/](robot_hal) | Board support component (LED, motors, sensors, ...) |

`robot_hal` is a normal ESP-IDF component, added through `EXTRA_COMPONENT_DIRS` in
the top-level [CMakeLists.txt](CMakeLists.txt). It hides the pinout and the
drivers, so application code such as `main.c` stays readable. Only
`status_led.h` matters for this sample:

```c
esp_err_t status_led_init(void);   /* configure the GPIO as an output */
void      status_led_set(bool on); /* solid on / off */
void      status_led_on(void);
void      status_led_off(void);
void      status_led_toggle(void);
```

## Troubleshooting

| Symptom | Likely cause |
| --- | --- |
| `Could not open port` / `no such file or directory` | Wrong `-p` port, or a charge-only USB cable |
| Nothing in the monitor | Board is in download mode - press the reset button |
| `idf.py: command not found` | ESP-IDF environment not exported (`export.bat` on Windows, `. $HOME/esp/esp-idf/export.sh` on Linux/macOS) |
| Build fails with a missing component | `idf.py fullclean`, then build again |
| The LED never lights up | Board revision uses a different LED pin - check `LED` in [robot_hal/include/pinout.h](robot_hal/include/pinout.h) |
