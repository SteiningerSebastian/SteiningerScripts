# ESP-IDF project file. The three lines below are the mandatory boilerplate;
# the order matters.
cmake_minimum_required(VERSION 3.22)

# Makes robot_hal/ visible as a normal component, so "REQUIRES robot_hal" in
# main/CMakeLists.txt works without installing anything.
set(EXTRA_COMPONENT_DIRS "${CMAKE_CURRENT_LIST_DIR}/robot_hal")

include($ENV{IDF_PATH}/tools/cmake/project.cmake)
# "Trim" the build. Include the minimal set of components, main, and anything it depends on.
idf_build_set_property(MINIMAL_BUILD ON)
project(blink)
