/*
 * ===========================================================================
 * RobotIT Lab board - sample "blink"
 * ===========================================================================
 *
 * Goal: two FreeRTOS tasks share one piece of data (is the status LED on?).
 * Because they share it, they also share the LED. The sample shows how to
 * protect such shared state with a mutex, and why a *timeout* on taking the
 * mutex is better than waiting forever.
 *
 *   +--------------------+                    +--------------------+
 *   |  monitoring_task   |                    |     blink_task     |
 *   |     priority 1     |                    |     priority 2     |
 *   |    every 500 ms    |                    |    every 500 ms    |
 *   +----------+---------+                    +----------+---------+
 *              |                                         |
 *              | xSemaphoreTake(s_state.mutex, 100 ms)   |
 *              +--------------------+--------------------+
 *                                   |
 *                        +--------------------+
 *                        |    shared state    |
 *                        |   bool   led_on    |
 *                        |  mutex  (handle)   |
 *                        +----------+---------+
 *                                   |
 *                        +--------------------+
 *                        |  status LED (IO2)  |
 *                        +--------------------+
 *
 * What you should see in the serial monitor:
 *   - "[blink]   LED state: ON/OFF" and "[monitor] LED state: ON/OFF" lines
 *     appear alternately, and both always agree with each other.
 *   - The LED is lit for 500 ms, then dark for 500 ms.
 *
 * Ideas for experiments are listed in README.md ("Things to try").
 *
 * Hardware note: this board's status LED is on GPIO2 (see
 * robot_hal/include/pinout.h). The application never talks to the GPIO driver
 * directly - it goes through the robot_hal "status_led" module, exactly like it
 * would with any other driver of the board.
 * ===========================================================================
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"

#include "esp_err.h"

#include "status_led.h"

/* Log tag. Every message below starts with "blink: ", which makes it easy to
 * filter the output of this sample. The sample prints with plain printf():
 * the Velxio simulator builds with the ESP_LOGI/ESP_LOGD macros compiled out,
 * so ESP_LOGx() info lines would show up on the real board only. */
static const char *TAG = "blink";

/* --------------------------------------------------------------------------
 * Tunables - change these to reproduce the experiments in README.md
 * ------------------------------------------------------------------------ */

/** Time the LED stays in one state: 500 ms on, then 500 ms off. */
#define BLINK_PERIOD_MS     500

/** How often the monitoring task reads the shared state. */
#define MONITOR_PERIOD_MS   500

/** Worst case a task waits for the mutex before giving up (milliseconds). */
#define MUTEX_TIMEOUT_MS    100

/* FreeRTOS always runs the highest-priority task that is ready to run.
 * Switching a GPIO is cheap, so the blink task gets the higher priority: that
 * keeps the blink rhythm steady. The monitoring task only logs, which can
 * afford to wait a little. */
#define BLINK_TASK_PRIORITY     2
#define MONITOR_TASK_PRIORITY   1

/* Stack size in bytes. printf() formats the string on the task's own stack
 * and needs well over a kilobyte for that on top of the task's locals; with
 * 2048 the monitor task overflows. 4096 is a safe starting point. If you make
 * a task do more work, raise its stack. */
#define BLINK_TASK_STACK        4096
#define MONITOR_TASK_STACK      4096

/* --------------------------------------------------------------------------
 * Shared state
 * ------------------------------------------------------------------------ */

/**
 * @brief Data that both tasks use.
 *
 * @c mutex guards @c led_on *and* the LED itself: only the task that currently
 * holds the mutex is allowed to read or write them. That is what keeps the
 * value in @c led_on and the real hardware in sync.
 *
 * The @c s_ prefix marks a `static` variable - it belongs to this file only,
 * no other .c file can reach it.
 */
typedef struct {
    bool led_on;              /**< true while the status LED is lit */
    SemaphoreHandle_t mutex;  /**< mutex protecting led_on and the LED */
} shared_state_t;

static shared_state_t s_state;

/* --------------------------------------------------------------------------
 * Tasks
 * ------------------------------------------------------------------------ */

/**
 * @brief Periodically report the shared LED state.
 *
 * This is the "reader". It models a telemetry or user-interface task that
 * wants to know what the rest of the firmware is doing. It never drives the
 * GPIO itself; it only reads @c s_state.led_on - and therefore has to obey the
 * same mutex rules as the writer.
 *
 * @param arg Unused, but required by the FreeRTOS task signature.
 */
static void monitoring_task(void *arg)
{
    (void)arg; /* silence the "unused parameter" warning */

    while (true) {
        if (xSemaphoreTake(s_state.mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
            printf("%s: [monitor] LED state: %s\n", TAG, s_state.led_on ? "ON" : "OFF");

            /* Always give the mutex back, on every path out of the critical
             * section. Forgetting this once locks up the other task forever. */
            xSemaphoreGive(s_state.mutex);
        } else {
            /* Somebody else still holds the mutex. Skip this round instead of
             * blocking indefinitely: one slow task must not stall the system. */
            printf("%s: [monitor] mutex busy for >%d ms, skipping\n",
                   TAG, MUTEX_TIMEOUT_MS);
        }

        vTaskDelay(pdMS_TO_TICKS(MONITOR_PERIOD_MS));
    }
}

/**
 * @brief Flip the status LED every @ref BLINK_PERIOD_MS.
 *
 * This is the "writer": it owns the LED and keeps @c s_state.led_on in sync
 * with the real hardware, so the reader always sees reality.
 *
 * @param arg Unused, but required by the FreeRTOS task signature.
 */
static void blink_task(void *arg)
{
    (void)arg;

    while (true) {
        if (xSemaphoreTake(s_state.mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
            /* Update the bookkeeping and the hardware inside the same critical
             * section, so no task can ever observe a half-done toggle. */
            s_state.led_on = !s_state.led_on;
            status_led_set(s_state.led_on);
            printf("%s: [blink]   LED state: %s\n", TAG, s_state.led_on ? "ON" : "OFF");

            xSemaphoreGive(s_state.mutex);
        } else {
            printf("%s: [blink] mutex busy for >%d ms, skipping\n",
                   TAG, MUTEX_TIMEOUT_MS);
        }

        vTaskDelay(pdMS_TO_TICKS(BLINK_PERIOD_MS));
    }
}

/* --------------------------------------------------------------------------
 * Entry point
 * ------------------------------------------------------------------------ */

/**
 * @brief Set up the hardware, then start the two tasks.
 *
 * app_main() runs once, inside the "main" task. It is allowed to return - the
 * tasks created here keep running on their own.
 */
void app_main(void)
{
    printf("%s: starting the blink sample\n", TAG);

    /* Create the mutex *before* any task exists, otherwise a task could get a
     * NULL handle. A mutex (not a binary semaphore) is the right choice here:
     * it records which task owns it and enables priority inheritance, so a
     * low-priority holder is boosted while a high-priority task waits. */
    s_state.mutex = xSemaphoreCreateMutex();
    if (s_state.mutex == NULL) {
        printf("%s: ERROR: out of heap while creating the mutex\n", TAG);
        abort(); /* without the mutex nothing else in this sample is safe */
    }

    /* Claim the LED GPIO and start with the LED lit. ESP_ERROR_CHECK() logs and
     * aborts on failure, so below this line we can assume a working LED. */
    ESP_ERROR_CHECK(status_led_init());
    status_led_set(true);
    s_state.led_on = true;

    /* Create the reader first, the higher-priority writer last: a new task may
     * start running immediately, and creating it last keeps start-up order
     * easy to follow. */
    if (xTaskCreate(monitoring_task, "monitor", MONITOR_TASK_STACK, NULL,
                    MONITOR_TASK_PRIORITY, NULL) != pdPASS) {
        printf("%s: ERROR: failed to create the monitoring task\n", TAG);
        abort();
    }
    if (xTaskCreate(blink_task, "blink", BLINK_TASK_STACK, NULL,
                    BLINK_TASK_PRIORITY, NULL) != pdPASS) {
        printf("%s: ERROR: failed to create the blink task\n", TAG);
        abort();
    }

    printf("%s: tasks started, main task is finished\n", TAG);
}
