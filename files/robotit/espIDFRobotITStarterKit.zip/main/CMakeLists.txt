# Registers the one source file of this component.
#
# INCLUDE_DIRS "." lets main.c include "status_led.h" directly.
# REQUIRES robot_hal makes the board support component's headers visible and
# links it - that is where status_led_*() lives.
idf_component_register(SRCS "main.c"
                       INCLUDE_DIRS "."
                       REQUIRES robot_hal)
