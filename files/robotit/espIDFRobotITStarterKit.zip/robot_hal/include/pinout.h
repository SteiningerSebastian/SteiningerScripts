#pragma once

#include "driver/gpio.h"

#define LED                         GPIO_NUM_2
#define BUZZER                      GPIO_NUM_1
#define NOT_SLEEP                   GPIO_NUM_21

/* Onboard BOOT button (active low, externally pulled up). The bootloader
 * only samples it during reset/power-up to pick the download mode, so it is
 * free as a user button once the application runs. Holding it clears the
 * stored WiFi credentials and re-opens the setup portal
 * (see wifi_provisioning.h). */
#define BOOT_BUTTON                 GPIO_NUM_0

#define MOTOR_LEFT_IN1_GPIO         GPIO_NUM_5
#define MOTOR_LEFT_IN2_GPIO         GPIO_NUM_6
#define ENCODER_LEFT_A              GPIO_NUM_17
#define ENCODER_LEFT_B              GPIO_NUM_18

#define MOTOR_RIGHT_IN1_GPIO        GPIO_NUM_48
#define MOTOR_RIGHT_IN2_GPIO        GPIO_NUM_47
#define ENCODER_RIGHT_A             GPIO_NUM_15
#define ENCODER_RIGHT_B             GPIO_NUM_16

#define BATTERY_VOLTAGE_ADC_GPIO    GPIO_NUM_4
#define BATTERY_DIVIDER_RATIO       2.0f /* 100k + 100k = 2:1 divider to BAT+ */

#define SENSOR_ARRAY_I2C_SDA        GPIO_NUM_10
#define SENSOR_ARRAY_I2C_SCL        GPIO_NUM_11

#define XSHUT_SENSOR_1              GPIO_NUM_12
#define XSHUT_SENSOR_2              GPIO_NUM_13
#define XSHUT_SENSOR_3              GPIO_NUM_14