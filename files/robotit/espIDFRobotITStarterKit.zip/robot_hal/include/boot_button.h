#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file boot_button.h
 * @brief Onboard BOOT button (IO0) as a user input with long-press detection.
 *
 * The BOOT button is wired between IO0 and GND with an external pull-up, so
 * it reads low while pressed. The bootloader samples it only during reset /
 * power-up (to select the serial download mode), therefore it is free for
 * application use once app_main() runs.
 *
 * Polling is non-blocking: call boot_button_poll() from an existing loop that
 * ticks every ~10 ms (app_main()'s main loop does this). A long press is
 * reported once, when the button has been held for the requested time, and
 * re-armed after it is released again - so the callback never fires
 * repeatedly during a single hold.
 */

/**
 * @brief Configure IO0 as an input with pull-up and arm the long-press timer.
 *
 * Must be called once before any other function in this module.
 *
 * @param long_press_ms Hold time that counts as a long press (e.g. 3000).
 * @return ESP_OK on success.
 */
esp_err_t boot_button_init(uint32_t long_press_ms);

/**
 * @brief Poll the button and fire the long-press callback when due.
 *
 * Non-blocking; intended to be called from a loop every ~10 ms. Also
 * debounces the press, so contact bounce cannot produce a spurious trigger.
 */
void boot_button_poll(void);

/**
 * @brief Whether the button is currently held down.
 */
bool boot_button_is_pressed(void);

/**
 * @brief How long the button has been held, in milliseconds (0 if released).
 */
uint32_t boot_button_held_ms(void);

/**
 * @brief Register the callback invoked once per long press.
 *
 * @param cb Function called when the button has been held for the threshold.
 */
void boot_button_set_long_press_cb(void (*cb)(void));

#ifdef __cplusplus
}
#endif
