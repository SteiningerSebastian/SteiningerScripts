#pragma once

#include <stdint.h>

#include "esp_err.h"
#include "driver/gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file dc_motor.h
 * @brief Standalone DC motor driver (H-bridge on IN1/IN2, PWM via MCPWM).
 *
 * Drives a single DC motor through an H-bridge using the IN/IN interface:
 * the active direction's channel is PWM'd while the other is held low. PWM
 * is generated with the MCPWM peripheral, which is purpose-built for motor
 * control. This driver is independent of any encoder, so it can be used for
 * a motor with no feedback at all.
 */

/** Opaque DC motor handle. */
typedef struct dc_motor_s *dc_motor_handle_t;

/**
 * @brief DC motor configuration.
 */
typedef struct {
    gpio_num_t in1_gpio;  /*!< H-bridge IN1 (PWM) */
    gpio_num_t in2_gpio;  /*!< H-bridge IN2 (PWM) */
    bool invert;          /*!< Flip direction if the motor is mounted reversed */
    uint32_t pwm_freq_hz; /*!< PWM frequency for the H-bridge */
    int group_id;         /*!< MCPWM group to allocate from (0 or 1) */
} dc_motor_cfg_t;

/**
 * @brief Default DC motor configuration.
 *
 * @param m_in1 H-bridge IN1 pin
 * @param m_in2 H-bridge IN2 pin
 */
#define DC_MOTOR_CFG_DEFAULT(m_in1, m_in2) \
    {                                       \
        .in1_gpio = (m_in1), .in2_gpio = (m_in2), \
        .invert = false,                    \
        .pwm_freq_hz = 20000,               \
        .group_id = 0,                      \
    }

/**
 * @brief Create and initialise a DC motor (H-bridge PWM via MCPWM).
 *
 * Allocates an MCPWM timer, operator, comparator and two generators (one
 * per IN pin), then leaves the motor stopped.
 *
 * @param out Receives the new handle on success.
 * @param cfg Configuration. May be filled with DC_MOTOR_CFG_DEFAULT().
 * @return ESP_OK on success, or an error if init fails.
 */
esp_err_t dc_motor_init(dc_motor_handle_t *out, const dc_motor_cfg_t *cfg);

/**
 * @brief Set the motor PWM duty.
 *
 * @param m Motor handle.
 * @param duty Signed duty in the range -1.0 .. 1.0. Positive is always
 *        "forward" (the invert flag, if any, is applied internally); 0
 *        coasts to a stop.
 * @return ESP_OK on success.
 */
esp_err_t dc_motor_set_duty(dc_motor_handle_t m, float duty);

/**
 * @brief Stop the motor (both IN pins low).
 * @param m Motor handle.
 * @return ESP_OK on success.
 */
esp_err_t dc_motor_stop(dc_motor_handle_t m);

/**
 * @brief Brake the motor (both IN pins high).
 *
 * Drives both H-bridge inputs high, shorting the motor terminals so it
 * actively brakes instead of coasting. Use this for an emergency stop.
 *
 * @param m Motor handle.
 * @return ESP_OK on success.
 */
esp_err_t dc_motor_brake(dc_motor_handle_t m);

/**
 * @brief Change the invert flag at runtime.
 *
 * @param m Motor handle.
 * @param invert New invert state.
 * @return ESP_OK on success.
 */
esp_err_t dc_motor_set_invert(dc_motor_handle_t m, bool invert);

/**
 * @brief Destroy a motor and free its resources.
 * @param m Motor handle (may be NULL).
 * @return ESP_OK on success.
 */
esp_err_t dc_motor_deinit(dc_motor_handle_t m);

#ifdef __cplusplus
}
#endif
