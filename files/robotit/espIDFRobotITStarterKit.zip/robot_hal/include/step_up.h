#pragma once

#include <stdbool.h>

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file step_up.h
 * @brief Driver for the step-up (boost) converter via its NOT_SLEEP pin.
 *
 * The NOT_SLEEP pin (IO21) enables the boost converter that generates the
 * ~10V motor supply (VM). The driver is deliberately minimal: it only has
 * two states - on (active, converter running) and off (sleep, converter
 * disabled).
 */

/**
 * @brief Configure the NOT_SLEEP pin as an output and start in the off state.
 *
 * Must be called once before any other function in this module.
 *
 * @return ESP_OK on success, or an error if the GPIO config fails.
 */
esp_err_t step_up_init(void);

/**
 * @brief Turn the step-up converter on or off.
 *
 * @param on true = converter active, false = converter in sleep.
 */
void step_up_set(bool on);

/** @brief Turn the step-up converter on (NOT_SLEEP asserted high). */
void step_up_on(void);

/** @brief Turn the step-up converter off (NOT_SLEEP low, sleep mode). */
void step_up_off(void);

#ifdef __cplusplus
}
#endif
