#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file status_led.h
 * @brief Driver for the onboard status LED (IO2).
 *
 * The LED is a plain GPIO output. The driver offers both blocking and
 * non-blocking blink helpers so it can be driven either on its own or from
 * inside whatever polling loop the caller already runs.
 */

/**
 * @brief Configure the status LED GPIO as an output and turn it off.
 *
 * Must be called once before any other function in this module.
 *
 * @return ESP_OK on success, or an error if the GPIO config fails.
 */
esp_err_t status_led_init(void);

/**
 * @brief Turn the LED fully on or off (solid, no blinking).
 */
void status_led_set(bool on);

/** @brief Turn the LED on (solid). */
void status_led_on(void);

/** @brief Turn the LED off. */
void status_led_off(void);

/** @brief Invert the current LED state. */
void status_led_toggle(void);

/**
 * @brief Non-blocking blink helper.
 *
 * Toggles the LED based on wall-clock time. Call this once per iteration
 * from an existing polling loop; the blink rate is set by @p period_ms
 * (the time for a full on+off cycle). This lets the caller keep doing other
 * work while the LED blinks.
 *
 * @param period_ms Full blink period (on + off) in milliseconds.
 */
void status_led_blink(uint32_t period_ms);

/**
 * @brief Blocking blink helper.
 *
 * Blinks the LED for @p duration_ms and returns. Useful when nothing else
 * needs to happen during the blink (e.g. running a short test).
 *
 * @param period_ms  Full blink period (on + off) in milliseconds.
 * @param duration_ms How long to keep blinking before returning.
 */
void status_led_blink_for(uint32_t period_ms, uint32_t duration_ms);

#ifdef __cplusplus
}
#endif
