#pragma once

#include <stdint.h>

#include "driver/gpio.h"
#include "driver/i2c_master.h"

#include "vl53l0x.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file sensor_array.h
 * @brief Array of VL53L0X sensors on a shared I2C bus, one XSHUT pin each.
 *
 * Several VL53L0X sensors share one I2C bus. Since every VL53L0X defaults to
 * the same I2C address, at most one sensor may be enabled (XSHUT high) at a
 * time. This driver multiplexes them: enable one, read it, disable it, then
 * enable the next.
 *
 * It offers both a blocking "read everything" helper and a non-blocking
 * "step through one sensor at a time" interface so callers can overlap the
 * per-sensor boot delay with other work.
 */

/** Maximum number of sensors in the array. */
#define SENSOR_ARRAY_MAX_SENSORS 3

/** Opaque sensor array handle. */
typedef struct sensor_array_s *sensor_array_handle_t;

/**
 * @brief A single sensor in the array.
 */
typedef struct {
    gpio_num_t xshut_gpio; /*!< XSHUT pin for this sensor */
} sensor_array_member_t;

/**
 * @brief Result of a full array scan.
 */
typedef struct {
    bool valid[SENSOR_ARRAY_MAX_SENSORS]; /*!< Whether each sensor returned a value */
    uint16_t distance_mm[SENSOR_ARRAY_MAX_SENSORS]; /*!< Distance per sensor */
} sensor_array_result_t;

/**
 * @brief Sensor array configuration.
 */
typedef struct {
    i2c_master_bus_handle_t bus;              /*!< Shared I2C master bus */
    uint32_t i2c_speed_hz;                    /*!< I2C clock speed */
    uint32_t boot_delay_ms;                   /*!< Boot delay after each XSHUT high */
    uint32_t read_timeout_ms;                 /*!< Timeout waiting for each result */
    uint8_t count;                            /*!< Number of sensors in the array */
    sensor_array_member_t members[SENSOR_ARRAY_MAX_SENSORS]; /*!< XSHUT pins */
} sensor_array_cfg_t;

/**
 * @brief Create and initialise a sensor array.
 *
 * Creates one VL53L0X driver per member and enables the first sensor so a
 * sensor_array_next() can read it immediately.
 *
 * @param out Receives the new handle on success.
 * @param cfg Configuration.
 * @return ESP_OK on success.
 */
esp_err_t sensor_array_init(sensor_array_handle_t *out, const sensor_array_cfg_t *cfg);

/**
 * @brief Synchronously read all sensors and return their distances.
 *
 * Enables each sensor in turn, reads it (blocking until the result is
 * ready), disables it, then moves to the next. Fills @p result.
 *
 * @param a Array handle.
 * @param result Receives the distances.
 * @return ESP_OK on success.
 */
esp_err_t sensor_array_read_all(sensor_array_handle_t a, sensor_array_result_t *result);

/**
 * @brief Advance the incremental scan by one sensor.
 *
 * Reads the currently-enabled sensor, disables it, then enables the next
 * one (wrapping around with a modulo operation), and writes the current
 * sensor's distance into @a result at its index. Designed to be called in a
 * loop by a caller that does other work while each next sensor boots.
 *
 * The first sensor is enabled by @ref sensor_array_init, so the first call
 * to this function already reads sensor 0.
 *
 * @param a Array handle.
 * @param result Receives updated distances.
 * @return true if a sensor was read this call, false on invalid arguments.
 */
bool sensor_array_next(sensor_array_handle_t a, sensor_array_result_t *result);

/**
 * @brief Re-read the currently-enabled sensor without disabling or switching.
 *
 * Leaves the sensor enabled and its cursor unchanged, so repeated calls to
 * this function poll the same sensor. This is faster than
 * sensor_array_next() because it avoids the per-sensor boot delay: the
 * sensor stays powered and just issues a new ranging read.
 *
 * @param a Array handle.
 * @param result Receives the distance of the current sensor at its index.
 * @return true if the current sensor was read, false on invalid arguments.
 */
bool sensor_array_read_current(sensor_array_handle_t a, sensor_array_result_t *result);

/**
 * @brief Read the diagnostics of the most recent read of one sensor.
 *
 * @param a Array handle (may be NULL -> zeroed diag).
 * @param index Sensor index (clamped to the array).
 * @param diag Receives the diagnostic information.
 */
void sensor_array_get_diag(sensor_array_handle_t a, uint8_t index, vl53l0x_diag_t *diag);

/**
 * @brief Destroy a sensor array and free its resources.
 * @param a Array handle (may be NULL).
 * @return ESP_OK on success.
 */
esp_err_t sensor_array_deinit(sensor_array_handle_t a);

#ifdef __cplusplus
}
#endif
