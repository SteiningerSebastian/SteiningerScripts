#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "esp_err.h"
#include "driver/gpio.h"

#include "dc_motor.h"
#include "encoder.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file motor.h
 * @brief Composite motor driver: assembles a DC motor + quadrature encoder.
 *
 * A "motor" here is the combination of a @ref dc_motor (H-bridge PWM on
 * IN1/IN2) and an optional @ref encoder (quadrature A/B). The composite
 * bundles the two into a single handle so the caller talks to one motor
 * object, while the underlying drivers stay separate and reusable on their
 * own (a motor without an encoder, or an encoder without a motor).
 *
 * Motors can be physically integrated either way round, so the composite
 * carries an invert flag. When set, both the H-bridge direction and the
 * encoder sign are flipped, so "positive speed" always means the same
 * physical direction (forward) no matter how the motor was mounted.
 */

/** Opaque composite motor handle. */
typedef struct motor_s *motor_handle_t;

/**
 * @brief Composite motor configuration.
 *
 * The @ref dc_motor and @ref encoder sub-configs are embedded directly.
 * Set @ref motor_cfg_t::has_encoder to false to build a motor with no
 * feedback (the encoder fields are then ignored).
 */
typedef struct {
    dc_motor_cfg_t dc;   /*!< DC motor (H-bridge) sub-config */
    encoder_cfg_t enc;   /*!< Encoder sub-config */
    bool has_encoder;    /*!< true to attach an encoder, false for a plain motor */
    bool invert;         /*!< Flip direction + encoder sign if the motor is mounted reversed */
} motor_cfg_t;

/**
 * @brief Default composite motor configuration.
 *
 * @param m_in1 H-bridge IN1 pin
 * @param m_in2 H-bridge IN2 pin
 * @param m_a   Encoder phase A pin
 * @param m_b   Encoder phase B pin
 */
#define MOTOR_CFG_DEFAULT(m_in1, m_in2, m_a, m_b)                 \
    {                                                             \
        .dc = DC_MOTOR_CFG_DEFAULT(m_in1, m_in2),                 \
        .enc = ENCODER_CFG_DEFAULT(m_a, m_b),                     \
        .has_encoder = true,                                      \
        .invert = false,                                          \
    }

/**
 * @brief Create and initialise a composite motor.
 *
 * Creates the DC motor (and, if @ref motor_cfg_t::has_encoder is set, the
 * encoder) and leaves the motor stopped.
 *
 * @param out Receives the new handle on success.
 * @param cfg Configuration. May be filled with MOTOR_CFG_DEFAULT().
 * @return ESP_OK on success, or an error if init fails.
 */
esp_err_t motor_init(motor_handle_t *out, const motor_cfg_t *cfg);

/**
 * @brief Set the motor PWM duty.
 *
 * @param m Motor handle.
 * @param duty Signed duty in the range -1.0 .. 1.0. Positive is always
 *        "forward" (the invert flag, if any, is applied internally); 0
 *        coasts to a stop.
 * @return ESP_OK on success.
 */
esp_err_t motor_set_duty(motor_handle_t m, float duty);

/**
 * @brief Stop the motor (both IN pins low).
 * @param m Motor handle.
 * @return ESP_OK on success.
 */
esp_err_t motor_stop(motor_handle_t m);

/**
 * @brief Brake the motor (both IN pins high).
 *
 * Shorts the motor terminals so it actively brakes instead of coasting.
 * Use this for an emergency stop.
 *
 * @param m Motor handle.
 * @return ESP_OK on success.
 */
esp_err_t motor_brake(motor_handle_t m);

/**
 * @brief Read the current encoder count (signed).
 *
 * Only valid if the motor was created with an encoder. A forward move
 * yields a positive count regardless of the invert flag.
 *
 * @param m Motor handle.
 * @param counts Receives the signed encoder count.
 * @return ESP_OK on success, or ESP_ERR_NOT_SUPPORTED if the motor has no encoder.
 */
esp_err_t motor_read_counts(motor_handle_t m, int32_t *counts);

/**
 * @brief Reset the encoder count to zero.
 * @param m Motor handle.
 * @return ESP_OK on success, or ESP_ERR_NOT_SUPPORTED if the motor has no encoder.
 */
esp_err_t motor_reset_counts(motor_handle_t m);

/**
 * @brief Change the invert flag at runtime.
 *
 * @param m Motor handle.
 * @param invert New invert state.
 * @return ESP_OK on success.
 */
esp_err_t motor_set_invert(motor_handle_t m, bool invert);

/**
 * @brief Destroy a composite motor and free its resources.
 * @param m Motor handle (may be NULL).
 * @return ESP_OK on success.
 */
esp_err_t motor_deinit(motor_handle_t m);

#ifdef __cplusplus
}
#endif
