#pragma once

#include <stdint.h>

#include "esp_err.h"
#include "driver/gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file encoder.h
 * @brief Standalone quadrature encoder driver (PCNT on A/B phases).
 *
 * Decodes a quadrature encoder's A/B phases with the PCNT peripheral and
 * reports a signed position count. This driver is independent of any motor
 * so it can be used on its own (e.g. a hand-turned wheel, or a motor that
 * only needs position feedback).
 */

/** Opaque encoder handle. */
typedef struct encoder_s *encoder_handle_t;

/**
 * @brief Encoder configuration.
 */
typedef struct {
    gpio_num_t a_gpio;        /*!< Encoder phase A */
    gpio_num_t b_gpio;        /*!< Encoder phase B */
    int16_t high_limit;       /*!< PCNT high limit */
    int16_t low_limit;        /*!< PCNT low limit */
} encoder_cfg_t;

/**
 * @brief Default encoder configuration.
 *
 * @param m_a Encoder phase A pin
 * @param m_b Encoder phase B pin
 */
#define ENCODER_CFG_DEFAULT(m_a, m_b) \
    {                                  \
        .a_gpio = (m_a), .b_gpio = (m_b), \
        .high_limit = 30000, .low_limit = -30000, \
    }

/**
 * @brief Create and initialise an encoder.
 *
 * Configures a PCNT unit for quadrature decoding of the A/B phases and
 * starts counting from zero.
 *
 * @param out Receives the new handle on success.
 * @param cfg Configuration. May be filled with ENCODER_CFG_DEFAULT().
 * @return ESP_OK on success, or an error if init fails.
 */
esp_err_t encoder_init(encoder_handle_t *out, const encoder_cfg_t *cfg);

/**
 * @brief Read the current signed encoder count.
 *
 * @param enc Encoder handle.
 * @param counts Receives the signed count.
 * @return ESP_OK on success.
 */
esp_err_t encoder_read_counts(encoder_handle_t enc, int32_t *counts);

/**
 * @brief Reset the encoder count to zero.
 * @param enc Encoder handle.
 * @return ESP_OK on success.
 */
esp_err_t encoder_reset_counts(encoder_handle_t enc);

/**
 * @brief Convert an encoder count delta to output-shaft RPM.
 *
 * Applies PCNT counter wrap correction (the counter wraps at the configured
 * high/low limit) and converts counts to RPM using the counts-per-revolution
 * figure (which includes the gearbox).
 *
 * @param delta Counts accumulated over @p dt.
 * @param dt    Elapsed time in seconds (> 0).
 * @param counts_per_rev Encoder counts per output-shaft revolution.
 * @param wrap_limit PCNT counter wrap threshold (e.g. 30000).
 * @return The measured output-shaft speed in RPM.
 */
float encoder_counts_to_rpm(int32_t delta, float dt, float counts_per_rev, int32_t wrap_limit);

/**
 * @brief Destroy an encoder and free its resources.
 * @param enc Encoder handle (may be NULL).
 * @return ESP_OK on success.
 */
esp_err_t encoder_deinit(encoder_handle_t enc);

#ifdef __cplusplus
}
#endif
