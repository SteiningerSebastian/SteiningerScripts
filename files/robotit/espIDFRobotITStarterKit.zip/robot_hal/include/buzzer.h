#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file buzzer.h
 * @brief Buzzer driver (IO1).
 *
 * The buzzer pin is driven with a LEDC PWM square wave so both active and
 * passive buzzers work: an active buzzer beeps at its built-in tone when a
 * signal is present, a passive buzzer reproduces the driven frequency. The
 * frequency is therefore a best-effort pitch for passive buzzers and merely
 * an on/off gate for active ones.
 *
 * Three kinds of output exist:
 *  - named fixed sounds (startup chime, WiFi/WebSocket cues), see
 *    buzzer_sound_t,
 *  - a single beep of a given length (pulse),
 *  - arbitrary melodies: arrays of frequencies + durations, repeated.
 *
 * All playback is non-blocking from a dedicated task fed by a small queue;
 * callers never wait. buzzer_stop() aborts any playing melody between notes
 * (and is itself a no-op when nothing plays). A newly queued sound also
 * cancels whatever is playing.
 */

/** Available fixed sounds. */
typedef enum {
    BUZZER_SOUND_STARTUP = 0,           /*!< Rising three-beep chime at boot */
    BUZZER_SOUND_WIFI_CONNECTED,        /*!< WiFi associated, got IP */
    BUZZER_SOUND_WIFI_DISCONNECTED,     /*!< WiFi lost */
    BUZZER_SOUND_WS_CONNECTED,          /*!< Server WebSocket link up */
    BUZZER_SOUND_WS_DISCONNECTED,       /*!< Server WebSocket link down */
    BUZZER_SOUND_COUNT,                 /*!< Number of sounds (internal) */
} buzzer_sound_t;

/** Maximum notes accepted in one melody request. */
#define BUZZER_MAX_NOTES 32

/** Melody repetition bounds. */
#define BUZZER_MIN_REPEAT 1
#define BUZZER_MAX_REPEAT 20

/**
 * @brief Configure the buzzer GPIO (LEDC PWM) and start the playback task.
 *
 * Must be called once before any other function in this module.
 *
 * @return ESP_OK on success.
 */
esp_err_t buzzer_init(void);

/**
 * @brief Queue a fixed sound for playback (non-blocking).
 *
 * Cancels whatever is currently playing (including a running melody).
 *
 * @param sound Which sound to play.
 */
void buzzer_play(buzzer_sound_t sound);

/**
 * @brief Queue a single beep (non-blocking).
 *
 * Cancels whatever is currently playing.
 *
 * @param ms Beep length in milliseconds (clamped to 10..2000).
 * @param freq_hz Beep frequency in Hz (0 = use the default frequency).
 */
void buzzer_pulse(uint32_t ms, uint32_t freq_hz);

/**
 * @brief Queue an arbitrary melody (non-blocking).
 *
 * The melody is played from the two parallel arrays: note i is driven at
 * freq[i] Hz for dur[i] ms. A frequency of 0 means silence for that note
 * (a rest). The whole melody is repeated @p repeat times.
 * Cancels whatever is currently playing.
 *
 * @param freq     Note frequencies in Hz (0 = rest).
 * @param dur_ms   Note durations in ms.
 * @param count    Number of notes (capped to BUZZER_MAX_NOTES).
 * @param repeat   How often to repeat the melody (clamped to
 *                 BUZZER_MIN_REPEAT..BUZZER_MAX_REPEAT).
 * @return ESP_OK on success, ESP_ERR_INVALID_ARG for bad parameters,
 *         ESP_ERR_NO_MEM when the internal storage is exhausted.
 */
esp_err_t buzzer_melody(const uint32_t *freq, const uint32_t *dur_ms,
                        int count, int repeat);

/**
 * @brief Abort the currently playing sound/melody and silence the buzzer.
 *
 * Safe to call anytime, also from ISR-adjacent contexts (event handlers):
 * it only sets a flag; the playback task honours it between notes.
 */
void buzzer_stop(void);

#ifdef __cplusplus
}
#endif