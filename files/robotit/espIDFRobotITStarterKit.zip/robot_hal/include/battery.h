#pragma once

#include <stdint.h>

#include "esp_err.h"
#include "esp_adc/adc_oneshot.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file battery.h
 * @brief Battery voltage driver (ADC + calibration).
 *
 * Reads the battery voltage through a 100k/100k (2:1) voltage divider on an
 * ADC channel. The driver owns an ADC oneshot unit and a curve-fitting
 * calibration handle, and reports the actual battery voltage in volts.
 */

/** Opaque battery handle. */
typedef struct battery_s *battery_handle_t;

/**
 * @brief Battery configuration.
 */
typedef struct {
    int adc_channel;      /*!< ADC channel the divider is connected to */
    float divider_ratio;  /*!< Divider ratio (BAT+ / ADC voltage), e.g. 2.0 for a 2:1 divider */
} battery_cfg_t;

/**
 * @brief Default battery configuration.
 *
 * @param m_channel ADC channel the divider is connected to
 */
#define BATTERY_CFG_DEFAULT(m_channel) \
    {                                   \
        .adc_channel = (m_channel),     \
        .divider_ratio = 2.0f,          \
    }

/**
 * @brief Create and initialise the battery voltage reader.
 *
 * Configures an ADC oneshot unit and a curve-fitting calibration scheme for
 * the given channel.
 *
 * @param out Receives the new handle on success.
 * @param cfg Configuration. May be filled with BATTERY_CFG_DEFAULT().
 * @return ESP_OK on success, or an error if init fails.
 */
esp_err_t battery_init(battery_handle_t *out, const battery_cfg_t *cfg);

/**
 * @brief Read the battery voltage in volts.
 *
 * Takes a single ADC sample, converts it to a calibrated voltage, and
 * multiplies by the divider ratio.
 *
 * @param b Battery handle.
 * @param volts Receives the battery voltage in volts.
 * @return ESP_OK on success, or an error if the read fails.
 */
esp_err_t battery_read_voltage(battery_handle_t b, float *volts);

/**
 * @brief Destroy a battery reader and free its resources.
 * @param b Battery handle (may be NULL).
 * @return ESP_OK on success.
 */
esp_err_t battery_deinit(battery_handle_t b);

#ifdef __cplusplus
}
#endif
