#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "driver/gpio.h"
#include "driver/i2c_master.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file vl53l0x.h
 * @brief Universal single-shot VL53L0X ToF distance sensor driver.
 *
 * Wraps a single VL53L0X sensor that lives on a shared I2C bus and is
 * selected by its own XSHUT pin (driven low to reset/hold the sensor, high
 * to power it up and take the bus). Because all VL53L0X sensors default to
 * the same I2C address, only one sensor on the bus may be enabled at a
 * time.
 *
 * The driver owns both the I2C device handle and the XSHUT GPIO. The caller
 * can enable/disable the sensor explicitly, read synchronously (blocking
 * until a result is ready), or split a read into "start" + "wait for it".
 */

/** Default I2C address of a VL53L0X. */
#define VL53L0X_I2C_ADDR 0x29

/** Outcome of the most recent read attempt (for diagnostics). */
typedef enum {
    VL53L0X_READ_OK = 0,       /*!< Reading succeeded */
    VL53L0X_READ_I2C_ERROR,    /*!< I2C transaction failed (NACK / bus timeout / wiring) */
    VL53L0X_READ_TIMEOUT,      /*!< Timed out waiting for the ranging result */
    VL53L0X_READ_NOT_ENABLED,  /*!< Sensor is disabled (enable failed earlier / XSHUT wiring) */
    VL53L0X_READ_BAD_STATUS,   /*!< Sensor rejected the measurement (see range_status) */
} vl53l0x_read_status_t;

/** Human-readable name for a read status (for logging). */
const char *vl53l0x_read_status_name(vl53l0x_read_status_t st);

/**
 * Human-readable name for a VL53L0X range status code (low nibble of reg
 * 0x14), per ST's API: 0=valid, 1=sigma fail, 2=signal fail, 3=min clip,
 * 4=out of bounds, 5=hardware fail, 6=valid (no wrap check), 7=wrap fail,
 * 8=processing fail, 9=xtalk fail, 0xA=raw underflow, 0xB=raw overflow.
 */
const char *vl53l0x_range_status_name(uint8_t rs);

/** Diagnostics of the most recent read. */
typedef struct {
    vl53l0x_read_status_t status; /*!< Outcome of the last read */
    uint8_t status_byte;          /*!< Full raw byte at reg 0x14 (MSB) */
    uint8_t range_status;         /*!< Range status (low nibble of status byte) */
    uint16_t range_mm;            /*!< Raw range value of the last completed measurement */
    uint8_t raw_block[12];        /*!< Full 12-byte result block at reg 0x14 */
    uint32_t io_errors;           /*!< Cumulative I2C transaction failures */
} vl53l0x_diag_t;

/** Opaque single-sensor handle. */
typedef struct vl53l0x_s *vl53l0x_handle_t;

/**
 * @brief VL53L0X configuration.
 */
typedef struct {
    i2c_master_bus_handle_t bus;   /*!< Shared I2C master bus */
    gpio_num_t xshut_gpio;         /*!< XSHUT pin for this sensor */
    uint32_t i2c_speed_hz;         /*!< I2C clock speed */
    uint32_t boot_delay_ms;        /*!< Time after XSHUT high before the sensor is ready (e.g. 10) */
    uint32_t read_timeout_ms;      /*!< Timeout waiting for a ranging result (e.g. 500) */
} vl53l0x_cfg_t;

/**
 * @brief Default VL53L0X configuration.
 *
 * @param m_bus  I2C master bus handle
 * @param m_xshut XSHUT GPIO
 */
#define VL53L0X_CFG_DEFAULT(m_bus, m_xshut) \
    {                                        \
        .bus = (m_bus), .xshut_gpio = (m_xshut), \
        .i2c_speed_hz = 400000,              \
        .boot_delay_ms = 30,                 \
        .read_timeout_ms = 500,              \
    }

/**
 * @brief Read the diagnostics of the most recent read attempt.
 *
 * @param s Sensor handle (may be NULL -> zeroed diag).
 * @param diag Receives the diagnostic information.
 */
void vl53l0x_get_diag(vl53l0x_handle_t s, vl53l0x_diag_t *diag);

/**
 * @brief Create and initialise a VL53L0X sensor driver.
 *
 * Adds the I2C device (at the default address), configures the XSHUT pin as
 * an output and leaves the sensor disabled (XSHUT low) so it does not
 * conflict with other sensors on the bus.
 *
 * @param out Receives the new handle on success.
 * @param cfg Configuration. May be filled with VL53L0X_CFG_DEFAULT().
 * @return ESP_OK on success.
 */
esp_err_t vl53l0x_init(vl53l0x_handle_t *out, const vl53l0x_cfg_t *cfg);

/**
 * @brief Enable the sensor (drive XSHUT high) and wait for it to boot.
 *
 * @param s Sensor handle.
 * @return ESP_OK on success.
 */
esp_err_t vl53l0x_enable(vl53l0x_handle_t s);

/**
 * @brief Disable the sensor (drive XSHUT low, back into reset).
 *
 * After this the sensor releases the I2C bus so another sensor at the same
 * address can be enabled.
 *
 * @param s Sensor handle.
 * @return ESP_OK on success.
 */
esp_err_t vl53l0x_disable(vl53l0x_handle_t s);

/**
 * @brief Synchronously read the distance in millimetres.
 *
 * The sensor must already be enabled. Blocks until a ranging result is
 * ready (or the timeout elapses).
 *
 * @param s Sensor handle.
 * @param out_mm Receives the distance in millimetres.
 * @return true on success, false on I2C error or timeout.
 */
bool vl53l0x_read_mm(vl53l0x_handle_t s, uint16_t *out_mm);

/**
 * @brief Start a ranging measurement (non-blocking).
 *
 * The sensor must already be enabled. Returns immediately after kicking off
 * the conversion; poll with vl53l0x_result_ready() and then read with
 * vl53l0x_fetch_mm(). Lets a caller do useful work while the sensor ranges.
 *
 * @param s Sensor handle.
 * @return true on success, false on I2C error.
 */
bool vl53l0x_start_measurement(vl53l0x_handle_t s);

/**
 * @brief Check whether a started measurement has a result ready.
 * @param s Sensor handle.
 * @return true if a result is available.
 */
bool vl53l0x_result_ready(vl53l0x_handle_t s);

/**
 * @brief Read out a completed measurement result.
 *
 * Only meaningful after vl53l0x_result_ready() returned true. Clears the
 * interrupt. Measurements whose range-status indicates a failed/bogus return
 * (weak signal, out of bounds, wrap failure) are rejected and report false,
 * so callers only see genuine, valid ranges.
 *
 * @param s Sensor handle.
 * @param out_mm Receives the distance in millimetres.
 * @return true on success, false on I2C error or a non-valid measurement.
 */
bool vl53l0x_fetch_result(vl53l0x_handle_t s, uint16_t *out_mm);

/**
 * @brief Destroy a sensor and free its resources.
 * @param s Sensor handle (may be NULL).
 * @return ESP_OK on success.
 */
esp_err_t vl53l0x_deinit(vl53l0x_handle_t s);

#ifdef __cplusplus
}
#endif
