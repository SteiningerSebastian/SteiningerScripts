#pragma once

#include <stddef.h>

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file kv_store.h
 * @brief Persistent key-value string store backed by NVS flash.
 *
 * Stores string values keyed by name, surviving power cycles. Values are
 * written to flash on kv_store_set() (committed immediately) and read back
 * with kv_store_get(). Useful for persisting configuration.
 *
 * The store uses a single NVS namespace. Keys are limited to 15 characters
 * (NVS key limit) and values to the NVS string size limit.
 */

/** Maximum length of a key (NVS limit). */
#define KV_STORE_MAX_KEY_LEN 15

/**
 * @brief Initialise the key-value store.
 *
 * Initialises the NVS flash partition (if not already done) and opens the
 * store's namespace. Must be called once before any other function.
 *
 * @return ESP_OK on success.
 */
esp_err_t kv_store_init(void);

/**
 * @brief Store a string value under a key.
 *
 * Writes the value and commits it to flash immediately.
 *
 * @param key   Key (max KV_STORE_MAX_KEY_LEN chars).
 * @param value Null-terminated string value.
 * @return ESP_OK on success, or an error if the key/value is invalid or the
 *         write fails.
 */
esp_err_t kv_store_set(const char *key, const char *value);

/**
 * @brief Load a string value for a key.
 *
 * @param key      Key to look up.
 * @param out_buf  Buffer to receive the value (including NUL terminator).
 * @param buf_size Size of @p out_buf in bytes.
 * @return ESP_OK on success, ESP_ERR_NVS_NOT_FOUND if the key does not
 *         exist, or an error if the value does not fit.
 */
esp_err_t kv_store_get(const char *key, char *out_buf, size_t buf_size);

/**
 * @brief Erase a single key.
 * @param key Key to erase.
 * @return ESP_OK on success, ESP_ERR_NVS_NOT_FOUND if the key does not exist.
 */
esp_err_t kv_store_erase(const char *key);

/**
 * @brief Erase all keys in the store.
 * @return ESP_OK on success.
 */
esp_err_t kv_store_erase_all(void);

#ifdef __cplusplus
}
#endif
