/*
 * Universal single-shot VL53L0X ToF distance sensor driver.
 *
 * Register sequences are ported from Pololu's VL53L0X Arduino library (MIT
 * licensed), which is itself derived from ST's VL53L0X API (STSW-IMG005).
 * This driver adds XSHUT-based enable/disable for sharing a single I2C bus
 * among several sensors at the same address, and splits a read into
 * start/ready/fetch so callers can overlap ranging with other work.
 */
#include <stdlib.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "esp_err.h"
#include "esp_timer.h"

#include "vl53l0x.h"

#define REG_SYSRANGE_START 0x00
#define REG_SYSTEM_SEQUENCE_CONFIG 0x01
#define REG_SYSTEM_INTERRUPT_CONFIG_GPIO 0x0A
#define REG_SYSTEM_INTERRUPT_CLEAR 0x0B
#define REG_RESULT_INTERRUPT_STATUS 0x13
#define REG_RESULT_RANGE_STATUS 0x14
#define REG_MSRC_CONFIG_CONTROL 0x60
#define REG_FINAL_RANGE_CONFIG_MIN_COUNT_RATE_RTN_LIMIT 0x44
#define REG_GLOBAL_CONFIG_SPAD_ENABLES_REF_0 0xB0
#define REG_GLOBAL_CONFIG_REF_EN_START_SELECT 0xB6
#define REG_DYNAMIC_SPAD_NUM_REQUESTED_REF_SPAD 0x4E
#define REG_DYNAMIC_SPAD_REF_EN_START_OFFSET 0x4F
#define REG_VHV_CONFIG_PAD_SCL_SDA_EXTSUP_HV 0x89
#define REG_GPIO_HV_MUX_ACTIVE_HIGH 0x84
#define REG_IDENTIFICATION_MODEL_ID 0xC0

/* Per-I2C-transaction timeout. A normal transaction at 400kHz takes
 * microseconds, so 20ms is generous for a healthy bus. When the motors
 * throttle up, PWM noise can corrupt the bus; a short timeout makes the
 * transaction fail fast instead of blocking the sensor loop for up to 200ms.
 * A failed read just marks the sensor invalid for that cycle. */
#define I2C_XFER_TIMEOUT_MS 20

static const char *TAG = "vl53l0x";

struct vl53l0x_s {
    i2c_master_dev_handle_t dev;
    gpio_num_t xshut_gpio;
    uint8_t stop_variable;
    uint32_t boot_delay_ms;
    uint32_t read_timeout_ms;
    bool io_error;
    bool enabled;
    /* Diagnostics of the last read (see vl53l0x_get_diag). */
    vl53l0x_read_status_t last_status;
    uint8_t last_status_byte;
    uint8_t last_range_status;
    uint16_t last_range_mm;
    uint8_t last_block[12];
    uint32_t io_error_count;
};

static int64_t now_ms(void) {
    return esp_timer_get_time() / 1000;
}

const char *vl53l0x_read_status_name(vl53l0x_read_status_t st) {
    switch (st) {
    case VL53L0X_READ_OK:          return "ok";
    case VL53L0X_READ_I2C_ERROR:   return "i2c-error";
    case VL53L0X_READ_TIMEOUT:     return "timeout";
    case VL53L0X_READ_NOT_ENABLED: return "not-enabled";
    case VL53L0X_READ_BAD_STATUS:  return "bad-status";
    default:                       return "unknown";
    }
}

const char *vl53l0x_range_status_name(uint8_t rs) {
    switch (rs) {
    case 0x0: return "valid";
    case 0x1: return "sigma-fail";
    case 0x2: return "signal-fail";
    case 0x3: return "min-clip";
    case 0x4: return "out-of-bounds";
    case 0x5: return "hw-fail";
    case 0x6: return "valid-nowrap";
    case 0x7: return "wrap-fail";
    case 0x8: return "processing-fail";
    case 0x9: return "xtalk-fail";
    case 0xA: return "raw-underflow";
    case 0xB: return "raw-overflow (no target in range)";
    default:  return "reserved";
    }
}

void vl53l0x_get_diag(vl53l0x_handle_t s, vl53l0x_diag_t *diag) {
    if (diag == NULL) return;
    if (s == NULL) {
        memset(diag, 0, sizeof(*diag));
        diag->status = VL53L0X_READ_NOT_ENABLED;
        return;
    }
    diag->status = s->last_status;
    diag->status_byte = s->last_status_byte;
    diag->range_status = s->last_range_status;
    diag->range_mm = s->last_range_mm;
    memcpy(diag->raw_block, s->last_block, sizeof(diag->raw_block));
    diag->io_errors = s->io_error_count;
}

/* Record a read outcome in the diagnostics. */
static void set_diag(vl53l0x_handle_t s, vl53l0x_read_status_t st,
                     uint8_t status_byte, uint16_t range_mm) {
    s->last_status = st;
    s->last_status_byte = status_byte;
    s->last_range_status = status_byte & 0x0F;
    s->last_range_mm = range_mm;
}

static void wr8(vl53l0x_handle_t s, uint8_t reg, uint8_t val) {
    uint8_t data[2] = {reg, val};
    if (i2c_master_transmit(s->dev, data, sizeof(data), I2C_XFER_TIMEOUT_MS) != ESP_OK) {
        s->io_error = true;
        s->io_error_count++;
    }
}

static void wr16(vl53l0x_handle_t s, uint8_t reg, uint16_t val) {
    uint8_t data[3] = {reg, (uint8_t)(val >> 8), (uint8_t)val};
    if (i2c_master_transmit(s->dev, data, sizeof(data), I2C_XFER_TIMEOUT_MS) != ESP_OK) {
        s->io_error = true;
        s->io_error_count++;
    }
}

static uint8_t rd8(vl53l0x_handle_t s, uint8_t reg) {
    uint8_t val = 0;
    if (i2c_master_transmit_receive(s->dev, &reg, 1, &val, 1, I2C_XFER_TIMEOUT_MS) != ESP_OK) {
        s->io_error = true;
        s->io_error_count++;
    }
    return val;
}

static uint16_t rd16(vl53l0x_handle_t s, uint8_t reg) {
    uint8_t val[2] = {0, 0};
    if (i2c_master_transmit_receive(s->dev, &reg, 1, val, 2, I2C_XFER_TIMEOUT_MS) != ESP_OK) {
        s->io_error = true;
        s->io_error_count++;
    }
    return (uint16_t)((val[0] << 8) | val[1]);
}

static void wr_multi(vl53l0x_handle_t s, uint8_t reg, const uint8_t *src, uint8_t count) {
    uint8_t data[17];
    data[0] = reg;
    for (uint8_t i = 0; i < count; i++) {
        data[i + 1] = src[i];
    }
    if (i2c_master_transmit(s->dev, data, (size_t)count + 1, I2C_XFER_TIMEOUT_MS) != ESP_OK) {
        s->io_error = true;
        s->io_error_count++;
    }
}

static void rd_multi(vl53l0x_handle_t s, uint8_t reg, uint8_t *dst, uint8_t count) {
    if (i2c_master_transmit_receive(s->dev, &reg, 1, dst, count, I2C_XFER_TIMEOUT_MS) != ESP_OK) {
        s->io_error = true;
        s->io_error_count++;
    }
}

static bool get_spad_info(vl53l0x_handle_t s, uint8_t *count, bool *type_is_aperture) {
    wr8(s, 0x80, 0x01);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x00, 0x00);

    wr8(s, 0xFF, 0x06);
    wr8(s, 0x83, rd8(s, 0x83) | 0x04);
    wr8(s, 0xFF, 0x07);
    wr8(s, 0x81, 0x01);

    wr8(s, 0x80, 0x01);

    wr8(s, 0x94, 0x6b);
    wr8(s, 0x83, 0x00);
    int64_t start = now_ms();
    while (rd8(s, 0x83) == 0x00) {
        if (s->io_error || now_ms() - start > s->read_timeout_ms) {
            return false;
        }
    }
    wr8(s, 0x83, 0x01);
    uint8_t tmp = rd8(s, 0x92);

    *count = tmp & 0x7f;
    *type_is_aperture = (tmp >> 7) & 0x01;

    wr8(s, 0x81, 0x00);
    wr8(s, 0xFF, 0x06);
    wr8(s, 0x83, rd8(s, 0x83) & ~0x04);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x00, 0x01);

    wr8(s, 0xFF, 0x00);
    wr8(s, 0x80, 0x00);

    return !s->io_error;
}

static bool perform_single_ref_calibration(vl53l0x_handle_t s, uint8_t vhv_init_byte) {
    wr8(s, REG_SYSRANGE_START, 0x01 | vhv_init_byte);

    int64_t start = now_ms();
    while ((rd8(s, REG_RESULT_INTERRUPT_STATUS) & 0x07) == 0) {
        if (s->io_error || now_ms() - start > s->read_timeout_ms) {
            return false;
        }
    }

    wr8(s, REG_SYSTEM_INTERRUPT_CLEAR, 0x01);
    wr8(s, REG_SYSRANGE_START, 0x00);

    return !s->io_error;
}

static bool sensor_init_regs(vl53l0x_handle_t s) {
    if (rd8(s, REG_IDENTIFICATION_MODEL_ID) != 0xEE) {
        return false; /* not responding / wrong device */
    }

    /* VL53L0X_DataInit(): most breakout modules run the sensor's IO at 2V8 */
    wr8(s, REG_VHV_CONFIG_PAD_SCL_SDA_EXTSUP_HV, rd8(s, REG_VHV_CONFIG_PAD_SCL_SDA_EXTSUP_HV) | 0x01);

    wr8(s, 0x88, 0x00); /* set I2C standard mode */

    wr8(s, 0x80, 0x01);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x00, 0x00);
    s->stop_variable = rd8(s, 0x91);
    wr8(s, 0x00, 0x01);
    wr8(s, 0xFF, 0x00);
    wr8(s, 0x80, 0x00);

    /* disable SIGNAL_RATE_MSRC and SIGNAL_RATE_PRE_RANGE limit checks */
    wr8(s, REG_MSRC_CONFIG_CONTROL, rd8(s, REG_MSRC_CONFIG_CONTROL) | 0x12);

    /* final range signal rate limit: 0.25 MCPS, Q9.7 fixed point */
    wr16(s, REG_FINAL_RANGE_CONFIG_MIN_COUNT_RATE_RTN_LIMIT, (uint16_t)(0.25f * (1 << 7)));

    wr8(s, REG_SYSTEM_SEQUENCE_CONFIG, 0xFF);

    /* VL53L0X_StaticInit() */
    uint8_t spad_count = 0;
    bool spad_type_is_aperture = false;
    if (!get_spad_info(s, &spad_count, &spad_type_is_aperture)) {
        return false;
    }

    uint8_t ref_spad_map[6];
    rd_multi(s, REG_GLOBAL_CONFIG_SPAD_ENABLES_REF_0, ref_spad_map, 6);

    wr8(s, 0xFF, 0x01);
    wr8(s, REG_DYNAMIC_SPAD_REF_EN_START_OFFSET, 0x00);
    wr8(s, REG_DYNAMIC_SPAD_NUM_REQUESTED_REF_SPAD, 0x2C);
    wr8(s, 0xFF, 0x00);
    wr8(s, REG_GLOBAL_CONFIG_REF_EN_START_SELECT, 0xB4);

    uint8_t first_spad_to_enable = spad_type_is_aperture ? 12 : 0;
    uint8_t spads_enabled = 0;
    for (uint8_t i = 0; i < 48; i++) {
        if (i < first_spad_to_enable || spads_enabled == spad_count) {
            ref_spad_map[i / 8] &= ~(1 << (i % 8));
        } else if ((ref_spad_map[i / 8] >> (i % 8)) & 0x1) {
            spads_enabled++;
        }
    }
    wr_multi(s, REG_GLOBAL_CONFIG_SPAD_ENABLES_REF_0, ref_spad_map, 6);

    /* default tuning settings */
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x00, 0x00);
    wr8(s, 0xFF, 0x00);
    wr8(s, 0x09, 0x00);
    wr8(s, 0x10, 0x00);
    wr8(s, 0x11, 0x00);
    wr8(s, 0x24, 0x01);
    wr8(s, 0x25, 0xFF);
    wr8(s, 0x75, 0x00);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x4E, 0x2C);
    wr8(s, 0x48, 0x00);
    wr8(s, 0x30, 0x20);
    wr8(s, 0xFF, 0x00);
    wr8(s, 0x30, 0x09);
    wr8(s, 0x54, 0x00);
    wr8(s, 0x31, 0x04);
    wr8(s, 0x32, 0x03);
    wr8(s, 0x40, 0x83);
    wr8(s, 0x46, 0x25);
    wr8(s, 0x60, 0x00);
    wr8(s, 0x27, 0x00);
    wr8(s, 0x50, 0x06);
    wr8(s, 0x51, 0x00);
    wr8(s, 0x52, 0x96);
    wr8(s, 0x56, 0x08);
    wr8(s, 0x57, 0x30);
    wr8(s, 0x61, 0x00);
    wr8(s, 0x62, 0x00);
    wr8(s, 0x64, 0x00);
    wr8(s, 0x65, 0x00);
    wr8(s, 0x66, 0xA0);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x22, 0x32);
    wr8(s, 0x47, 0x14);
    wr8(s, 0x49, 0xFF);
    wr8(s, 0x4A, 0x00);
    wr8(s, 0xFF, 0x00);
    wr8(s, 0x7A, 0x0A);
    wr8(s, 0x7B, 0x00);
    wr8(s, 0x78, 0x21);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x23, 0x34);
    wr8(s, 0x42, 0x00);
    wr8(s, 0x44, 0xFF);
    wr8(s, 0x45, 0x26);
    wr8(s, 0x46, 0x05);
    wr8(s, 0x40, 0x40);
    wr8(s, 0x0E, 0x06);
    wr8(s, 0x20, 0x1A);
    wr8(s, 0x43, 0x40);
    wr8(s, 0xFF, 0x00);
    wr8(s, 0x34, 0x03);
    wr8(s, 0x35, 0x44);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x31, 0x04);
    wr8(s, 0x4B, 0x09);
    wr8(s, 0x4C, 0x05);
    wr8(s, 0x4D, 0x04);
    wr8(s, 0xFF, 0x00);
    wr8(s, 0x44, 0x00);
    wr8(s, 0x45, 0x20);
    wr8(s, 0x47, 0x08);
    wr8(s, 0x48, 0x28);
    wr8(s, 0x67, 0x00);
    wr8(s, 0x70, 0x04);
    wr8(s, 0x71, 0x01);
    wr8(s, 0x72, 0xFE);
    wr8(s, 0x76, 0x00);
    wr8(s, 0x77, 0x00);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x0D, 0x01);
    wr8(s, 0xFF, 0x00);
    wr8(s, 0x80, 0x01);
    wr8(s, 0x01, 0xF8);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x8E, 0x01);
    wr8(s, 0x00, 0x01);
    wr8(s, 0xFF, 0x00);
    wr8(s, 0x80, 0x00);

    /* interrupt on new sample ready, active low, cleared */
    wr8(s, REG_SYSTEM_INTERRUPT_CONFIG_GPIO, 0x04);
    wr8(s, REG_GPIO_HV_MUX_ACTIVE_HIGH, rd8(s, REG_GPIO_HV_MUX_ACTIVE_HIGH) & ~0x10);
    wr8(s, REG_SYSTEM_INTERRUPT_CLEAR, 0x01);

    /* disable MSRC and TCC by default, keep pre-range + final-range */
    wr8(s, REG_SYSTEM_SEQUENCE_CONFIG, 0xE8);

    /* VL53L0X_PerformRefCalibration() */
    wr8(s, REG_SYSTEM_SEQUENCE_CONFIG, 0x01);
    if (!perform_single_ref_calibration(s, 0x40)) {
        return false;
    }
    wr8(s, REG_SYSTEM_SEQUENCE_CONFIG, 0x02);
    if (!perform_single_ref_calibration(s, 0x00)) {
        return false;
    }
    wr8(s, REG_SYSTEM_SEQUENCE_CONFIG, 0xE8);

    return !s->io_error;
}

esp_err_t vl53l0x_init(vl53l0x_handle_t *out, const vl53l0x_cfg_t *cfg) {
    if (out == NULL || cfg == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    vl53l0x_handle_t s = calloc(1, sizeof(*s));
    if (s == NULL) {
        return ESP_ERR_NO_MEM;
    }
    s->xshut_gpio = cfg->xshut_gpio;
    s->boot_delay_ms = cfg->boot_delay_ms;
    s->read_timeout_ms = cfg->read_timeout_ms;

    /* Configure XSHUT as an output, held low (sensor in reset / off the bus). */
    gpio_config_t gpio_cfg = {
        .pin_bit_mask = 1ULL << cfg->xshut_gpio,
        .mode = GPIO_MODE_OUTPUT,
    };
    esp_err_t err = gpio_config(&gpio_cfg);
    if (err != ESP_OK) {
        free(s);
        return err;
    }
    gpio_set_level(cfg->xshut_gpio, 0);

    /* Add the I2C device at the default address. */
    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = VL53L0X_I2C_ADDR,
        .scl_speed_hz = cfg->i2c_speed_hz,
    };
    err = i2c_master_bus_add_device(cfg->bus, &dev_cfg, &s->dev);
    if (err != ESP_OK) {
        free(s);
        return err;
    }

    *out = s;
    return ESP_OK;
}

esp_err_t vl53l0x_enable(vl53l0x_handle_t s) {
    if (s == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    /* A VL53L0X that was reset (XSHUT low) needs time to power up before it
     * answers on I2C and completes its reference calibration. Wait a generous
     * settle time and retry a few times, since the sensor can occasionally
     * take longer than the nominal boot time. */
    gpio_set_level(s->xshut_gpio, 1);
    vTaskDelay(pdMS_TO_TICKS(s->boot_delay_ms));

    for (int attempt = 0; attempt < 3; attempt++) {
        s->io_error = false;
        if (sensor_init_regs(s)) {
            s->enabled = true;
            return ESP_OK;
        }
        ESP_LOGE(TAG, "VL53L0X init attempt %d failed%s (io_errors=%u)",
                 attempt + 1, s->io_error ? " (I2C error - wiring/power/address conflict?)" : "",
                 (unsigned)s->io_error_count);
        vTaskDelay(pdMS_TO_TICKS(s->boot_delay_ms));
    }

    s->enabled = false;
    return ESP_FAIL;
}

esp_err_t vl53l0x_disable(vl53l0x_handle_t s) {
    if (s == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    gpio_set_level(s->xshut_gpio, 0);
    s->enabled = false;
    return ESP_OK;
}

bool vl53l0x_read_mm(vl53l0x_handle_t s, uint16_t *out_mm) {
    if (s == NULL || out_mm == NULL) {
        return false;
    }
    if (!s->enabled) {
        set_diag(s, VL53L0X_READ_NOT_ENABLED, 0, 0);
        return false;
    }
    if (!vl53l0x_start_measurement(s)) {
        set_diag(s, s->io_error ? VL53L0X_READ_I2C_ERROR : VL53L0X_READ_TIMEOUT, 0, 0);
        return false;
    }
    int64_t start = now_ms();
    while (!vl53l0x_result_ready(s)) {
        if (s->io_error) {
            set_diag(s, VL53L0X_READ_I2C_ERROR, 0, 0);
            return false;
        }
        if (now_ms() - start > s->read_timeout_ms) {
            set_diag(s, VL53L0X_READ_TIMEOUT, 0, 0);
            return false;
        }
    }
    if (!vl53l0x_fetch_result(s, out_mm)) {
        /* fetch_result already recorded the precise reason. */
        if (s->last_status == VL53L0X_READ_OK) {
            set_diag(s, s->io_error ? VL53L0X_READ_I2C_ERROR : VL53L0X_READ_TIMEOUT, 0, 0);
        }
        return false;
    }
    return true;
}

bool vl53l0x_start_measurement(vl53l0x_handle_t s) {
    if (s == NULL || !s->enabled) {
        return false;
    }
    wr8(s, 0x80, 0x01);
    wr8(s, 0xFF, 0x01);
    wr8(s, 0x00, 0x00);
    wr8(s, 0x91, s->stop_variable);
    wr8(s, 0x00, 0x01);
    wr8(s, 0xFF, 0x00);
    wr8(s, 0x80, 0x00);

    wr8(s, REG_SYSRANGE_START, 0x01);

    /* Wait for the start bit to clear (conversion underway). */
    int64_t start = now_ms();
    while (rd8(s, REG_SYSRANGE_START) & 0x01) {
        if (s->io_error || now_ms() - start > s->read_timeout_ms) {
            return false;
        }
    }
    return !s->io_error;
}

bool vl53l0x_result_ready(vl53l0x_handle_t s) {
    if (s == NULL || !s->enabled) {
        return false;
    }
    return (rd8(s, REG_RESULT_INTERRUPT_STATUS) & 0x07) != 0;
}

bool vl53l0x_fetch_result(vl53l0x_handle_t s, uint16_t *out_mm) {
    if (s == NULL || out_mm == NULL || !s->enabled) {
        return false;
    }
    /* NOTE: The range-status nibble is deliberately NOT used as a hard
     * validity gate, because on real sensor batches the status bits are
     * advisory — e.g. a healthy VL53L0X can frequently return 0x0B (raw
     * overflow, "no clear single target") or 0x01 (sigma fail) while still
     * producing a usable range. The hardware diagnostics program works
     * precisely because it ignores this nibble and reads the range. The
     * actual plausibility filter lives in the caller (20..2000 mm window),
     * so we mirror the diagnostics behaviour here: return the range on any
     * I2C-clean read. Assumes default linearity corrective gain (1000) and
     * no fractional ranging. */
    uint8_t status = rd8(s, REG_RESULT_RANGE_STATUS);
    uint16_t range = rd16(s, REG_RESULT_RANGE_STATUS + 10);
    /* Capture the full result block for diagnostics (signal rates, SPAD
     * counts) before the interrupt clear; the block spans 0x14..0x1F. */
    uint8_t block[12];
    rd_multi(s, REG_RESULT_RANGE_STATUS, block, sizeof(block));
    memcpy(s->last_block, block, sizeof(block));
    wr8(s, REG_SYSTEM_INTERRUPT_CLEAR, 0x01);
    if (s->io_error) {
        set_diag(s, VL53L0X_READ_I2C_ERROR, 0, 0);
        return false;
    }
    /* Record the raw status byte so failures remain diagnosable, but DO NOT
     * reject based on it (see NOTE above). */
    set_diag(s, VL53L0X_READ_OK, status, range);
    *out_mm = range;
    return true;
}

esp_err_t vl53l0x_deinit(vl53l0x_handle_t s) {
    if (s == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    vl53l0x_disable(s);
    i2c_master_bus_rm_device(s->dev);
    free(s);
    return ESP_OK;
}
