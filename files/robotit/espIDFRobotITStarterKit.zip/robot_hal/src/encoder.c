/*
 * Standalone quadrature encoder driver for the RobotCar main board.
 *
 * Decodes a quadrature encoder's A/B phases with the PCNT peripheral and
 * reports a signed position count. Kept independent of any motor so it can
 * be reused on its own.
 */
#include <stdlib.h>

#include "driver/pulse_cnt.h"
#include "esp_err.h"

#include "encoder.h"

struct encoder_s {
    pcnt_unit_handle_t pcnt;
};

static void encoder_cleanup(encoder_handle_t enc) {
    if (enc->pcnt != NULL) {
        pcnt_unit_disable(enc->pcnt);
        pcnt_del_unit(enc->pcnt);
    }
    free(enc);
}

esp_err_t encoder_init(encoder_handle_t *out, const encoder_cfg_t *cfg) {
    if (out == NULL || cfg == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    encoder_handle_t enc = calloc(1, sizeof(*enc));
    if (enc == NULL) {
        return ESP_ERR_NO_MEM;
    }

    pcnt_unit_config_t unit_cfg = {
        .high_limit = cfg->high_limit,
        .low_limit = cfg->low_limit,
    };
    esp_err_t err = pcnt_new_unit(&unit_cfg, &enc->pcnt);
    if (err != ESP_OK) {
        encoder_cleanup(enc);
        return err;
    }

    pcnt_glitch_filter_config_t filter_cfg = {.max_glitch_ns = 1000};
    pcnt_unit_set_glitch_filter(enc->pcnt, &filter_cfg);

    pcnt_chan_config_t chan_a_cfg = {.edge_gpio_num = cfg->a_gpio, .level_gpio_num = cfg->b_gpio};
    pcnt_channel_handle_t chan_a;
    err = pcnt_new_channel(enc->pcnt, &chan_a_cfg, &chan_a);
    if (err != ESP_OK) {
        encoder_cleanup(enc);
        return err;
    }
    pcnt_channel_set_edge_action(chan_a, PCNT_CHANNEL_EDGE_ACTION_DECREASE, PCNT_CHANNEL_EDGE_ACTION_INCREASE);
    pcnt_channel_set_level_action(chan_a, PCNT_CHANNEL_LEVEL_ACTION_KEEP, PCNT_CHANNEL_LEVEL_ACTION_INVERSE);

    pcnt_chan_config_t chan_b_cfg = {.edge_gpio_num = cfg->b_gpio, .level_gpio_num = cfg->a_gpio};
    pcnt_channel_handle_t chan_b;
    err = pcnt_new_channel(enc->pcnt, &chan_b_cfg, &chan_b);
    if (err != ESP_OK) {
        encoder_cleanup(enc);
        return err;
    }
    pcnt_channel_set_edge_action(chan_b, PCNT_CHANNEL_EDGE_ACTION_INCREASE, PCNT_CHANNEL_EDGE_ACTION_DECREASE);
    pcnt_channel_set_level_action(chan_b, PCNT_CHANNEL_LEVEL_ACTION_KEEP, PCNT_CHANNEL_LEVEL_ACTION_INVERSE);

    err = pcnt_unit_enable(enc->pcnt);
    if (err != ESP_OK) {
        encoder_cleanup(enc);
        return err;
    }
    pcnt_unit_clear_count(enc->pcnt);
    err = pcnt_unit_start(enc->pcnt);
    if (err != ESP_OK) {
        encoder_cleanup(enc);
        return err;
    }

    *out = enc;
    return ESP_OK;
}

esp_err_t encoder_read_counts(encoder_handle_t enc, int32_t *counts) {
    if (enc == NULL || counts == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    int val = 0;
    esp_err_t err = pcnt_unit_get_count(enc->pcnt, &val);
    if (err != ESP_OK) {
        return err;
    }
    *counts = val;
    return ESP_OK;
}

esp_err_t encoder_reset_counts(encoder_handle_t enc) {
    if (enc == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    return pcnt_unit_clear_count(enc->pcnt);
}

esp_err_t encoder_deinit(encoder_handle_t enc) {
    if (enc == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    pcnt_unit_disable(enc->pcnt);
    pcnt_del_unit(enc->pcnt);
    free(enc);
    return ESP_OK;
}

float encoder_counts_to_rpm(int32_t delta, float dt, float counts_per_rev, int32_t wrap_limit) {
    if (dt <= 0.0f || counts_per_rev <= 0.0f || wrap_limit <= 0) {
        return 0.0f;
    }
    /* Correct for PCNT counter wrap. */
    if (delta > wrap_limit) {
        delta -= 2 * wrap_limit;
    } else if (delta < -wrap_limit) {
        delta += 2 * wrap_limit;
    }
    return (float)delta / dt / counts_per_rev * 60.0f;
}
