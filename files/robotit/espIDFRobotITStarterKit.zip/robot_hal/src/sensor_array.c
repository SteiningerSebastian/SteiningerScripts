/*
 * Array of VL53L0X sensors on a shared I2C bus, one XSHUT pin each.
 *
 * Because every VL53L0X defaults to the same I2C address, only one sensor
 * may be enabled at a time. This driver multiplexes them and offers both a
 * blocking scan and an incremental scan that overlaps each sensor's ranging
 * with the caller's own work.
 */
#include <stdlib.h>
#include <string.h>

#include "esp_err.h"

#include "vl53l0x.h"
#include "sensor_array.h"

struct sensor_array_s {
    vl53l0x_handle_t sensors[SENSOR_ARRAY_MAX_SENSORS];
    uint8_t count;
    uint8_t cursor;  /*!< Index of the currently enabled sensor */
    bool running;    /*!< Whether a sensor is currently enabled */
};

esp_err_t sensor_array_init(sensor_array_handle_t *out, const sensor_array_cfg_t *cfg) {
    if (out == NULL || cfg == NULL || cfg->count == 0 || cfg->count > SENSOR_ARRAY_MAX_SENSORS) {
        return ESP_ERR_INVALID_ARG;
    }

    sensor_array_handle_t a = calloc(1, sizeof(*a));
    if (a == NULL) {
        return ESP_ERR_NO_MEM;
    }
    a->count = cfg->count;

    for (uint8_t i = 0; i < cfg->count; i++) {
        vl53l0x_cfg_t scfg = VL53L0X_CFG_DEFAULT(cfg->bus, cfg->members[i].xshut_gpio);
        scfg.i2c_speed_hz = cfg->i2c_speed_hz;
        scfg.boot_delay_ms = cfg->boot_delay_ms;
        scfg.read_timeout_ms = cfg->read_timeout_ms;
        esp_err_t err = vl53l0x_init(&a->sensors[i], &scfg);
        if (err != ESP_OK) {
            /* Clean up sensors created so far. */
            for (uint8_t j = 0; j < i; j++) {
                vl53l0x_deinit(a->sensors[j]);
            }
            free(a);
            return err;
        }
    }

    /* Enable the first sensor right away so the first sensor_array_next()
     * call can read it. */
    a->cursor = 0;
    a->running = true;
    vl53l0x_enable(a->sensors[0]);

    *out = a;
    return ESP_OK;
}

esp_err_t sensor_array_read_all(sensor_array_handle_t a, sensor_array_result_t *result) {
    if (a == NULL || result == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    for (uint8_t i = 0; i < a->count; i++) {
        result->valid[i] = false;
        result->distance_mm[i] = 0;
    }
    for (uint8_t i = 0; i < a->count; i++) {
        if (vl53l0x_enable(a->sensors[i]) != ESP_OK) {
            continue;
        }
        uint16_t mm = 0;
        if (vl53l0x_read_mm(a->sensors[i], &mm)) {
            result->valid[i] = true;
            result->distance_mm[i] = mm;
        }
        vl53l0x_disable(a->sensors[i]);
    }
    return ESP_OK;
}

bool sensor_array_next(sensor_array_handle_t a, sensor_array_result_t *result) {
    if (a == NULL || result == NULL || a->count == 0) {
        return false;
    }

    /* Read the currently enabled sensor, then disable it. */
    uint8_t i = a->cursor;
    uint16_t mm = 0;
    result->valid[i] = vl53l0x_read_mm(a->sensors[i], &mm);
    result->distance_mm[i] = mm;
    vl53l0x_disable(a->sensors[i]);

    /* Move the pointer to the next sensor (wrap with modulo) and enable it
     * so its ranging overlaps the caller's work. */
    a->cursor = (a->cursor + 1) % a->count;
    vl53l0x_enable(a->sensors[a->cursor]);

    return true;
}

bool sensor_array_read_current(sensor_array_handle_t a, sensor_array_result_t *result) {
    if (a == NULL || result == NULL || a->count == 0 || !a->running) {
        return false;
    }

    /* Re-read the currently enabled sensor. It stays enabled and the cursor
     * is unchanged, so no boot delay is incurred on the next call. */
    uint8_t i = a->cursor;
    uint16_t mm = 0;
    result->valid[i] = vl53l0x_read_mm(a->sensors[i], &mm);
    result->distance_mm[i] = mm;
    return true;
}

void sensor_array_get_diag(sensor_array_handle_t a, uint8_t index, vl53l0x_diag_t *diag) {
    if (diag == NULL) return;
    if (a == NULL || index >= a->count) {
        memset(diag, 0, sizeof(*diag));
        diag->status = VL53L0X_READ_NOT_ENABLED;
        return;
    }
    vl53l0x_get_diag(a->sensors[index], diag);
}

esp_err_t sensor_array_deinit(sensor_array_handle_t a) {
    if (a == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    for (uint8_t i = 0; i < a->count; i++) {
        if (a->sensors[i] != NULL) {
            vl53l0x_deinit(a->sensors[i]);
        }
    }
    free(a);
    return ESP_OK;
}
