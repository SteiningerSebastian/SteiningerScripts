/*
 * Buzzer driver (IO1).
 *
 * The pin is driven with a LEDC PWM square wave, so both active and passive
 * buzzers work: an active buzzer beeps whenever a signal is present (the
 * frequency barely matters), a passive buzzer reproduces the frequency.
 *
 * Playback runs on a dedicated low-priority task fed by a small queue, so
 * callers never block. Three request types exist (fixed sounds, single
 * pulse, arbitrary melody); every new request CANCELS whatever is playing,
 * and buzzer_stop() aborts the current playback between notes. Abort is
 * cooperative: the note loop checks a flag every few milliseconds, so the
 * worst-case stop latency is one note.
 */
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/ledc.h"
#include "esp_err.h"

#include "pinout.h"
#include "buzzer.h"

/*
 * The buzzer (IO1) is optional hardware: some builds have it, some do not.
 * When CONFIG_ROBOT_HAL_ENABLE_BUZZER is disabled the pin and the LEDC
 * channel are NOT claimed and every public function becomes a no-op, so
 * modules that always call buzzer_play()/buzzer_melody()/... work unchanged
 * on a robot without a buzzer.
 */
#if CONFIG_ROBOT_HAL_ENABLE_BUZZER

/* LEDC setup: one channel, timer 0. 10-bit duty. The buzzer on IO1 is a
 * PASSIVE type: it only makes sound when driven with a square wave whose
 * frequency sets the pitch (a constant level is SILENT - measured: 100%
 * duty produced no sound). Volume scales with duty in the mid range, so
 * BUZZER_LEDC_DUTY is the volume knob: 512 = 50% = loudest square wave.
 * (An ACTIVE buzzer, which beeps at its own built-in pitch whenever power
 * is applied, would want 1023 instead - set it back if the type changes.) */
#define BUZZER_LEDC_TIMER LEDC_TIMER_0
#define BUZZER_LEDC_CHANNEL LEDC_CHANNEL_0
#define BUZZER_LEDC_MODE LEDC_LOW_SPEED_MODE
#define BUZZER_LEDC_DUTY 512 /* 50 % = loudest square wave */
/* Default pitch. 5 kHz sounded sharp/piercing; ~2 kHz is a friendlier,
 * clearly audible tone for a passive buzzer (and close to the resonant
 * peak of common 25 mm passive elements). */
#define BUZZER_DEFAULT_FREQ_HZ 2000
/* LEDC cannot go below ~19 Hz with this clock config; clamp requests. */
#define BUZZER_MIN_FREQ_HZ 20
#define BUZZER_MAX_FREQ_HZ 20000

/* Note durations (ms) for the fixed sounds. */
#define TONE_SHORT 70
#define TONE_MED 130
#define TONE_LONG 220

/* Pause between notes (ms). */
#define GAP 50

/* One step of a fixed sound: drive state + duration. ms == 0 terminates. */
struct buzz_step {
    uint16_t ms;
    bool drive;
};

static const struct buzz_step *const SOUNDS[BUZZER_SOUND_COUNT] = {
    /* Startup: rising three-beep chime (robot is alive). */
    [BUZZER_SOUND_STARTUP] = (const struct buzz_step[]){
        { TONE_MED, true }, { GAP, false },
        { TONE_MED, true }, { GAP, false },
        { TONE_LONG, true }, { 0, false },
    },
    /* WiFi connected: short + long ascending pair. */
    [BUZZER_SOUND_WIFI_CONNECTED] = (const struct buzz_step[]){
        { TONE_SHORT, true }, { GAP, false },
        { TONE_LONG, true }, { 0, false },
    },
    /* WiFi disconnected: long + short descending pair. */
    [BUZZER_SOUND_WIFI_DISCONNECTED] = (const struct buzz_step[]){
        { TONE_LONG, true }, { GAP, false },
        { TONE_SHORT, true }, { 0, false },
    },
    /* WebSocket connected: three quick beeps (data link is live). */
    [BUZZER_SOUND_WS_CONNECTED] = (const struct buzz_step[]){
        { TONE_SHORT, true }, { GAP, false },
        { TONE_SHORT, true }, { GAP, false },
        { TONE_MED, true }, { 0, false },
    },
    /* WebSocket disconnected: two slow sombre beeps. */
    [BUZZER_SOUND_WS_DISCONNECTED] = (const struct buzz_step[]){
        { TONE_MED, true }, { GAP, false },
        { TONE_MED, true }, { 0, false },
    },
};

/* ---- queued playback requests ---- */

enum req_type { REQ_SOUND, REQ_PULSE, REQ_MELODY };

struct buzz_request {
    enum req_type type;
    /* REQ_SOUND / REQ_PULSE */
    buzzer_sound_t sound;
    uint32_t ms;
    uint32_t freq_hz;
    /* REQ_MELODY */
    uint32_t freq[BUZZER_MAX_NOTES];
    uint32_t dur[BUZZER_MAX_NOTES];
    int notes;
    int repeat;
};

#define BUZZ_QUEUE_LEN 8

/* Melody storage lives inside the request struct: 32 notes x (4+4) bytes
 * = 256 B per queued request, 8 requests = ~2 KB of queue storage. */

/* Run the playback task on the PRO CPU (core 0) like the other non-real-
 * time tasks; robot_hal cannot include robot_app.h (main component), so
 * the core is pinned here directly. */
#define BUZZER_CORE 0

static QueueHandle_t s_queue;

/* Set by buzzer_stop(); the playback loop checks it between notes (and
 * mid-note in short slices) and aborts the current sequence. */
static volatile bool s_abort;

/* ---- LEDC helpers ---- */

static void tone_start(uint32_t freq_hz) {
    if (freq_hz < BUZZER_MIN_FREQ_HZ) freq_hz = BUZZER_MIN_FREQ_HZ;
    if (freq_hz > BUZZER_MAX_FREQ_HZ) freq_hz = BUZZER_MAX_FREQ_HZ;
    /* Update the timer period live: one timer serves the single channel. */
    ledc_set_freq(BUZZER_LEDC_MODE, BUZZER_LEDC_TIMER, freq_hz);
    ledc_set_duty(BUZZER_LEDC_MODE, BUZZER_LEDC_CHANNEL, BUZZER_LEDC_DUTY);
    ledc_update_duty(BUZZER_LEDC_MODE, BUZZER_LEDC_CHANNEL);
}

static void tone_stop(void) {
    /* Drive the pin LOW (0 % duty) so an active buzzer is fully silent. */
    ledc_set_duty(BUZZER_LEDC_MODE, BUZZER_LEDC_CHANNEL, 0);
    ledc_update_duty(BUZZER_LEDC_MODE, BUZZER_LEDC_CHANNEL);
}

/* Delay in <=20 ms slices so aborts react quickly even inside long notes. */
static bool delay_abortable(uint32_t ms) {
    while (ms > 0) {
        if (s_abort) {
            return false;
        }
        uint32_t slice = ms > 20 ? 20 : ms;
        vTaskDelay(pdMS_TO_TICKS(slice));
        ms -= slice;
        if (ms == 0 && s_abort) {
            return false;
        }
    }
    return !s_abort;
}

/* Play one fixed sound pattern. Returns false when aborted. */
static bool play_sound(buzzer_sound_t sound) {
    const struct buzz_step *steps = SOUNDS[sound];
    for (int i = 0; steps[i].ms != 0; i++) {
        if (steps[i].drive) {
            tone_start(BUZZER_DEFAULT_FREQ_HZ);
        } else {
            tone_stop();
        }
        if (!delay_abortable(steps[i].ms)) {
            tone_stop();
            return false;
        }
    }
    tone_stop();
    return true;
}

/* Play one pulse. Returns false when aborted. */
static bool play_pulse(uint32_t ms, uint32_t freq_hz) {
    if (freq_hz == 0) {
        freq_hz = BUZZER_DEFAULT_FREQ_HZ;
    }
    tone_start(freq_hz);
    bool done = delay_abortable(ms);
    tone_stop();
    return done;
}

/* Play one melody pass. Returns false when aborted. */
static bool play_melody_once(const struct buzz_request *r) {
    for (int i = 0; i < r->notes; i++) {
        if (r->freq[i] == 0) {
            tone_stop(); /* rest */
        } else {
            tone_start(r->freq[i]);
        }
        if (!delay_abortable(r->dur[i])) {
            tone_stop();
            return false;
        }
    }
    tone_stop();
    return true;
}

static void buzzer_task(void *arg) {
    (void)arg;
    struct buzz_request r;
    for (;;) {
        if (xQueueReceive(s_queue, &r, portMAX_DELAY) != pdTRUE) {
            continue;
        }
        s_abort = false;
        bool finished = true;
        switch (r.type) {
        case REQ_SOUND:
            finished = play_sound(r.sound);
            break;
        case REQ_PULSE:
            finished = play_pulse(r.ms, r.freq_hz);
            break;
        case REQ_MELODY:
            for (int rep = 0; rep < r.repeat; rep++) {
                if (!play_melody_once(&r)) {
                    finished = false;
                    break;
                }
                /* Small gap between repeats so successive tones separate. */
                if (rep + 1 < r.repeat && !delay_abortable(60)) {
                    finished = false;
                    break;
                }
            }
            break;
        }
        (void)finished;
        /* Ensure silence after any playback (aborted or completed). */
        tone_stop();
    }
}

esp_err_t buzzer_init(void) {
    /* LEDC timer + channel on the buzzer pin. */
    ledc_timer_config_t timer_cfg = {
        .speed_mode = BUZZER_LEDC_MODE,
        .timer_num = BUZZER_LEDC_TIMER,
        .duty_resolution = LEDC_TIMER_10_BIT,
        .freq_hz = BUZZER_DEFAULT_FREQ_HZ,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    esp_err_t err = ledc_timer_config(&timer_cfg);
    if (err != ESP_OK) {
        return err;
    }
    ledc_channel_config_t ch_cfg = {
        .speed_mode = BUZZER_LEDC_MODE,
        .channel = BUZZER_LEDC_CHANNEL,
        .timer_sel = BUZZER_LEDC_TIMER,
        .intr_type = LEDC_INTR_DISABLE,
        .gpio_num = BUZZER,
        .duty = 0, /* silent at boot */
        .hpoint = 0,
        .flags.output_invert = 0,
    };
    err = ledc_channel_config(&ch_cfg);
    if (err != ESP_OK) {
        return err;
    }
    /* Maximum drive strength: stronger output driver = more current into
     * the buzzer = noticeably louder, at no cost here (the pin drives
     * nothing else). */
    gpio_set_drive_capability(BUZZER, GPIO_DRIVE_CAP_3);
    s_queue = xQueueCreate(BUZZ_QUEUE_LEN, sizeof(struct buzz_request));
    if (s_queue == NULL) {
        return ESP_ERR_NO_MEM;
    }

    BaseType_t ok = xTaskCreatePinnedToCore(buzzer_task, "buzzer", 2048, NULL,
                                            1, NULL, BUZZER_CORE);
    return (ok == pdPASS) ? ESP_OK : ESP_ERR_NO_MEM;
}

void buzzer_play(buzzer_sound_t sound) {
    if (s_queue == NULL || sound >= BUZZER_SOUND_COUNT) {
        return;
    }
    struct buzz_request r = {0};
    r.type = REQ_SOUND;
    r.sound = sound;
    /* Non-blocking: abort current playback, drop the request when full. */
    s_abort = true;
    xQueueSend(s_queue, &r, 0);
}

void buzzer_pulse(uint32_t ms, uint32_t freq_hz) {
    if (s_queue == NULL) {
        return;
    }
    if (ms < 10) ms = 10;
    if (ms > 2000) ms = 2000;
    struct buzz_request r = {0};
    r.type = REQ_PULSE;
    r.ms = ms;
    r.freq_hz = freq_hz;
    s_abort = true;
    xQueueSend(s_queue, &r, 0);
}

esp_err_t buzzer_melody(const uint32_t *freq, const uint32_t *dur_ms,
                        int count, int repeat) {
    if (s_queue == NULL || freq == NULL || dur_ms == NULL || count <= 0) {
        return ESP_ERR_INVALID_ARG;
    }
    if (count > BUZZER_MAX_NOTES) {
        count = BUZZER_MAX_NOTES;
    }
    if (repeat < BUZZER_MIN_REPEAT) repeat = BUZZER_MIN_REPEAT;
    if (repeat > BUZZER_MAX_REPEAT) repeat = BUZZER_MAX_REPEAT;

    struct buzz_request r = {0};
    r.type = REQ_MELODY;
    r.notes = count;
    r.repeat = repeat;
    for (int i = 0; i < count; i++) {
        r.freq[i] = freq[i];
        /* Clamp note length: a single absurd note must not lock the queue. */
        uint32_t d = dur_ms[i];
        if (d < 10) d = 10;
        if (d > 2000) d = 2000;
        r.dur[i] = d;
    }
    s_abort = true;
    if (xQueueSend(s_queue, &r, 0) != pdTRUE) {
        return ESP_ERR_NO_MEM;
    }
    return ESP_OK;
}

void buzzer_stop(void) {
    s_abort = true;
}

#else /* !CONFIG_ROBOT_HAL_ENABLE_BUZZER: buzzer not fitted - no-ops. */

esp_err_t buzzer_init(void) {
    return ESP_OK;
}

void buzzer_play(buzzer_sound_t sound) {
    (void)sound;
}

void buzzer_pulse(uint32_t ms, uint32_t freq_hz) {
    (void)ms;
    (void)freq_hz;
}

esp_err_t buzzer_melody(const uint32_t *freq, const uint32_t *dur_ms,
                        int count, int repeat) {
    (void)freq;
    (void)dur_ms;
    (void)count;
    (void)repeat;
    return ESP_OK;
}

void buzzer_stop(void) {
}

#endif /* CONFIG_ROBOT_HAL_ENABLE_BUZZER */