/*
 * Standalone DC motor driver for the RobotCar main board.
 *
 * Drives a single DC motor through an H-bridge using the IN/IN interface:
 * the active direction's channel is PWM'd while the other is held low. PWM
 * is generated with the MCPWM peripheral, which is purpose-built for motor
 * control. Kept independent of any encoder so it can be reused for a motor
 * with no feedback.
 */
#include <stdlib.h>

#include "driver/mcpwm_timer.h"
#include "driver/mcpwm_oper.h"
#include "driver/mcpwm_cmpr.h"
#include "driver/mcpwm_gen.h"
#include "esp_err.h"

#include "dc_motor.h"

struct dc_motor_s {
    mcpwm_timer_handle_t timer;
    mcpwm_oper_handle_t oper;
    mcpwm_cmpr_handle_t cmpr;
    mcpwm_gen_handle_t gen1; /* IN1 */
    mcpwm_gen_handle_t gen2; /* IN2 */
    uint32_t period_ticks;
    bool invert;
};

static void dc_motor_cleanup(dc_motor_handle_t m) {
    if (m->gen2 != NULL) {
        mcpwm_del_generator(m->gen2);
    }
    if (m->gen1 != NULL) {
        mcpwm_del_generator(m->gen1);
    }
    if (m->cmpr != NULL) {
        mcpwm_del_comparator(m->cmpr);
    }
    if (m->oper != NULL) {
        mcpwm_del_operator(m->oper);
    }
    if (m->timer != NULL) {
        mcpwm_del_timer(m->timer);
    }
    free(m);
}

esp_err_t dc_motor_init(dc_motor_handle_t *out, const dc_motor_cfg_t *cfg) {
    if (out == NULL || cfg == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    dc_motor_handle_t m = calloc(1, sizeof(*m));
    if (m == NULL) {
        return ESP_ERR_NO_MEM;
    }
    m->invert = cfg->invert;

    /* MCPWM timer. Use a 1 MHz resolution so period_ticks == period in us. */
    mcpwm_timer_config_t timer_cfg = {
        .group_id = cfg->group_id,
        .clk_src = MCPWM_TIMER_CLK_SRC_DEFAULT,
        .resolution_hz = 1000000,
        .count_mode = MCPWM_TIMER_COUNT_MODE_UP,
        .period_ticks = 1000000 / cfg->pwm_freq_hz,
    };
    m->period_ticks = timer_cfg.period_ticks;
    esp_err_t err = mcpwm_new_timer(&timer_cfg, &m->timer);
    if (err != ESP_OK) {
        dc_motor_cleanup(m);
        return err;
    }

    /* Operator. */
    mcpwm_operator_config_t oper_cfg = {
        .group_id = cfg->group_id,
    };
    err = mcpwm_new_operator(&oper_cfg, &m->oper);
    if (err != ESP_OK) {
        dc_motor_cleanup(m);
        return err;
    }
    err = mcpwm_operator_connect_timer(m->oper, m->timer);
    if (err != ESP_OK) {
        dc_motor_cleanup(m);
        return err;
    }

    /* Comparator (duty). */
    mcpwm_comparator_config_t cmpr_cfg = {
        .flags.update_cmp_on_tez = true,
    };
    err = mcpwm_new_comparator(m->oper, &cmpr_cfg, &m->cmpr);
    if (err != ESP_OK) {
        dc_motor_cleanup(m);
        return err;
    }
    mcpwm_comparator_set_compare_value(m->cmpr, 0);

    /* Two generators, one per IN pin. Each generator is forced low the
     * moment it exists: with the comparator at 0 the compare event may not
     * fire, so an unfenced pin would sit HIGH for whole periods once the
     * timer starts while its partner pin is still Hi-Z (pulled low by the
     * H-bridge's internal pulldown) — that HIGH/LOW pair drives the motor
     * full-duty for a few ms at init, which shows up as a power-on jerk. */
    mcpwm_generator_config_t gen_cfg = {
        .gen_gpio_num = cfg->in1_gpio,
    };
    err = mcpwm_new_generator(m->oper, &gen_cfg, &m->gen1);
    if (err != ESP_OK) {
        dc_motor_cleanup(m);
        return err;
    }
    mcpwm_generator_set_force_level(m->gen1, 0, true);
    gen_cfg.gen_gpio_num = cfg->in2_gpio;
    err = mcpwm_new_generator(m->oper, &gen_cfg, &m->gen2);
    if (err != ESP_OK) {
        dc_motor_cleanup(m);
        return err;
    }
    mcpwm_generator_set_force_level(m->gen2, 0, true);

    /* IN/IN H-bridge: each generator is high until the compare point, then
     * low. Driving one generator's duty to 0 (compare at 0) holds it low. */
    mcpwm_generator_set_action_on_timer_event(m->gen1,
        MCPWM_GEN_TIMER_EVENT_ACTION(MCPWM_TIMER_DIRECTION_UP, MCPWM_TIMER_EVENT_EMPTY, MCPWM_GEN_ACTION_HIGH));
    mcpwm_generator_set_action_on_compare_event(m->gen1,
        MCPWM_GEN_COMPARE_EVENT_ACTION(MCPWM_TIMER_DIRECTION_UP, m->cmpr, MCPWM_GEN_ACTION_LOW));
    mcpwm_generator_set_action_on_timer_event(m->gen2,
        MCPWM_GEN_TIMER_EVENT_ACTION(MCPWM_TIMER_DIRECTION_UP, MCPWM_TIMER_EVENT_EMPTY, MCPWM_GEN_ACTION_HIGH));
    mcpwm_generator_set_action_on_compare_event(m->gen2,
        MCPWM_GEN_COMPARE_EVENT_ACTION(MCPWM_TIMER_DIRECTION_UP, m->cmpr, MCPWM_GEN_ACTION_LOW));

    err = mcpwm_timer_enable(m->timer);
    if (err != ESP_OK) {
        dc_motor_cleanup(m);
        return err;
    }
    err = mcpwm_timer_start_stop(m->timer, MCPWM_TIMER_START_NO_STOP);
    if (err != ESP_OK) {
        dc_motor_cleanup(m);
        return err;
    }

    *out = m;
    return ESP_OK;
}

esp_err_t dc_motor_set_duty(dc_motor_handle_t m, float duty) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    if (duty > 1.0f) {
        duty = 1.0f;
    }
    if (duty < -1.0f) {
        duty = -1.0f;
    }

    bool forward = duty >= 0.0f;
    if (m->invert) {
        forward = !forward;
    }
    /* Multiply first, then cast: casting the float duty to uint32_t before
     * multiplying would truncate every fractional duty to 0 (so the motor
     * would only turn on at exactly 1.0). */
    uint32_t duty_ticks = (uint32_t)(m->period_ticks * (duty < 0.0f ? -duty : duty));

    /* IN/IN H-bridge: PWM the active direction's generator, hold the other low. */
    mcpwm_generator_set_force_level(forward ? m->gen2 : m->gen1, 0, true);
    mcpwm_comparator_set_compare_value(m->cmpr, duty_ticks);
    mcpwm_generator_set_force_level(forward ? m->gen1 : m->gen2, -1, true);
    return ESP_OK;
}

esp_err_t dc_motor_stop(dc_motor_handle_t m) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    mcpwm_generator_set_force_level(m->gen1, 0, true);
    mcpwm_generator_set_force_level(m->gen2, 0, true);
    return ESP_OK;
}

esp_err_t dc_motor_brake(dc_motor_handle_t m) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    /* Both IN pins high: short the motor terminals -> active braking. */
    mcpwm_generator_set_force_level(m->gen1, 1, true);
    mcpwm_generator_set_force_level(m->gen2, 1, true);
    return ESP_OK;
}

esp_err_t dc_motor_set_invert(dc_motor_handle_t m, bool invert) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    m->invert = invert;
    return ESP_OK;
}

esp_err_t dc_motor_deinit(dc_motor_handle_t m) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    dc_motor_stop(m);
    mcpwm_timer_disable(m->timer);
    mcpwm_del_generator(m->gen2);
    mcpwm_del_generator(m->gen1);
    mcpwm_del_comparator(m->cmpr);
    mcpwm_del_operator(m->oper);
    mcpwm_del_timer(m->timer);
    free(m);
    return ESP_OK;
}
