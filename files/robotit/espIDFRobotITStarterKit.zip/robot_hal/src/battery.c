/*
 * Battery voltage driver for the RobotCar main board.
 *
 * Reads the battery voltage through a 100k/100k (2:1) voltage divider on an
 * ADC channel. Uses an ADC oneshot unit plus a curve-fitting calibration
 * scheme to convert the raw sample to a real voltage, then applies the
 * divider ratio to recover the battery voltage.
 */
#include <stdlib.h>

#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"
#include "esp_err.h"

#include "battery.h"

struct battery_s {
    adc_oneshot_unit_handle_t adc;
    adc_cali_handle_t cali;
    adc_channel_t channel;
    float divider_ratio;
};

static void battery_cleanup(battery_handle_t b) {
    if (b->cali != NULL) {
        adc_cali_delete_scheme_curve_fitting(b->cali);
    }
    if (b->adc != NULL) {
        adc_oneshot_del_unit(b->adc);
    }
    free(b);
}

esp_err_t battery_init(battery_handle_t *out, const battery_cfg_t *cfg) {
    if (out == NULL || cfg == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    battery_handle_t b = calloc(1, sizeof(*b));
    if (b == NULL) {
        return ESP_ERR_NO_MEM;
    }
    b->channel = (adc_channel_t)cfg->adc_channel;
    b->divider_ratio = cfg->divider_ratio;

    adc_oneshot_unit_init_cfg_t unit_cfg = {
        .unit_id = ADC_UNIT_1,
    };
    esp_err_t err = adc_oneshot_new_unit(&unit_cfg, &b->adc);
    if (err != ESP_OK) {
        battery_cleanup(b);
        return err;
    }

    adc_oneshot_chan_cfg_t chan_cfg = {
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    err = adc_oneshot_config_channel(b->adc, b->channel, &chan_cfg);
    if (err != ESP_OK) {
        battery_cleanup(b);
        return err;
    }

    adc_cali_curve_fitting_config_t cali_cfg = {
        .unit_id = ADC_UNIT_1,
        .chan = b->channel,
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    err = adc_cali_create_scheme_curve_fitting(&cali_cfg, &b->cali);
    if (err != ESP_OK) {
        battery_cleanup(b);
        return err;
    }

    *out = b;
    return ESP_OK;
}

esp_err_t battery_read_voltage(battery_handle_t b, float *volts) {
    if (b == NULL || volts == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    int raw = 0;
    esp_err_t err = adc_oneshot_read(b->adc, b->channel, &raw);
    if (err != ESP_OK) {
        return err;
    }

    int mv = 0;
    err = adc_cali_raw_to_voltage(b->cali, raw, &mv);
    if (err != ESP_OK) {
        return err;
    }

    *volts = (mv / 1000.0f) * b->divider_ratio;
    return ESP_OK;
}

esp_err_t battery_deinit(battery_handle_t b) {
    if (b == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    battery_cleanup(b);
    return ESP_OK;
}
