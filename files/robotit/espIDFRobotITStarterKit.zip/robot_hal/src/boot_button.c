/*
 * Onboard BOOT button (IO0) as a user input.
 *
 * The button is a plain GPIO pulled up externally and shorted to GND when
 * pressed, so the raw level is 0 while it is down. The bootloader only
 * samples IO0 during reset/power-up, so once app_main() runs the pin is free
 * for the application.
 *
 * The press is debounced by requiring the raw level to stay unchanged for
 * BOOT_BUTTON_DEBOUNCE_MS before it is accepted. A long press fires its
 * callback exactly once, at the moment the hold time is reached, and is
 * re-armed only after the button has been released.
 */
#include <stdbool.h>
#include <stdint.h>

#include "driver/gpio.h"
#include "esp_err.h"
#include "esp_timer.h"

#include "pinout.h"
#include "boot_button.h"

/* Raw level must be stable this long before the press/release is accepted. */
#define BOOT_BUTTON_DEBOUNCE_MS 20

static uint32_t s_long_press_ms = 3000;
static void (*s_long_press_cb)(void);

/* Debounce state: last raw level and when it last changed. */
static int s_raw_level = 1;
static int64_t s_raw_change_ms;

/* Accepted (debounced) press state. */
static bool s_pressed;
static int64_t s_press_start_ms;
static bool s_triggered; /* long press already reported for this hold */

static int64_t now_ms(void) {
    return esp_timer_get_time() / 1000;
}

esp_err_t boot_button_init(uint32_t long_press_ms) {
    gpio_config_t cfg = {
        .pin_bit_mask = 1ULL << BOOT_BUTTON,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    esp_err_t err = gpio_config(&cfg);
    if (err != ESP_OK) {
        return err;
    }

    if (long_press_ms > 0) {
        s_long_press_ms = long_press_ms;
    }
    s_raw_level = gpio_get_level(BOOT_BUTTON);
    s_raw_change_ms = now_ms();
    s_pressed = false;
    s_press_start_ms = 0;
    s_triggered = false;
    return ESP_OK;
}

void boot_button_poll(void) {
    int64_t now = now_ms();
    int raw = gpio_get_level(BOOT_BUTTON);

    /* Track when the raw level last changed (debounce). */
    if (raw != s_raw_level) {
        s_raw_level = raw;
        s_raw_change_ms = now;
        return; /* still bouncing / too early to trust */
    }
    if (now - s_raw_change_ms < BOOT_BUTTON_DEBOUNCE_MS) {
        return;
    }

    bool down = (raw == 0);
    if (down) {
        if (!s_pressed) {
            /* Fresh press: start the hold timer. */
            s_pressed = true;
            s_press_start_ms = now;
            s_triggered = false;
        } else if (!s_triggered &&
                   (uint32_t)(now - s_press_start_ms) >= s_long_press_ms) {
            s_triggered = true;
            if (s_long_press_cb != NULL) {
                s_long_press_cb();
            }
        }
    } else {
        /* Released: re-arm for the next hold. */
        s_pressed = false;
        s_press_start_ms = 0;
        s_triggered = false;
    }
}

bool boot_button_is_pressed(void) {
    return s_pressed;
}

uint32_t boot_button_held_ms(void) {
    if (!s_pressed) {
        return 0;
    }
    int64_t held = now_ms() - s_press_start_ms;
    return held > 0 ? (uint32_t)held : 0;
}

void boot_button_set_long_press_cb(void (*cb)(void)) {
    s_long_press_cb = cb;
}
