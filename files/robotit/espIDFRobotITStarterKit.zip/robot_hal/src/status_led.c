/*
 * Status LED driver for the RobotCar main board.
 *
 * The status LED (IO2) is a plain GPIO output. This module wraps it with
 * solid on/off/toggle control plus blocking and non-blocking blink helpers,
 * so callers can either drive the blink from their own polling loop or let
 * the driver block briefly while nothing else needs to happen.
 */
#include <stdint.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_err.h"
#include "esp_timer.h"

#include "pinout.h"
#include "status_led.h"

static int64_t now_ms(void) {
    return esp_timer_get_time() / 1000;
}

esp_err_t status_led_init(void) {
    gpio_config_t cfg = {
        .pin_bit_mask = 1ULL << LED,
        .mode = GPIO_MODE_OUTPUT,
    };
    esp_err_t err = gpio_config(&cfg);
    if (err == ESP_OK) {
        gpio_set_level(LED, 0);
    }
    return err;
}

void status_led_set(bool on) {
    gpio_set_level(LED, on);
}

void status_led_on(void) {
    status_led_set(true);
}

void status_led_off(void) {
    status_led_set(false);
}

void status_led_toggle(void) {
    gpio_set_level(LED, !gpio_get_level(LED));
}

void status_led_blink(uint32_t period_ms) {
    status_led_set(((now_ms() / (period_ms / 2)) % 2) == 0);
}

void status_led_blink_for(uint32_t period_ms, uint32_t duration_ms) {
    int64_t start = now_ms();
    while (now_ms() - start < (int64_t)duration_ms) {
        status_led_blink(period_ms);
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}
