/*
 * Composite motor driver for the RobotCar main board.
 *
 * Assembles a standalone DC motor (H-bridge PWM) and an optional standalone
 * quadrature encoder into one handle. The composite applies the invert flag
 * to both the H-bridge direction and the encoder sign so that "positive
 * speed" always means the same physical direction regardless of how the
 * motor happened to be mounted.
 */
#include <stdlib.h>

#include "esp_err.h"

#include "dc_motor.h"
#include "encoder.h"
#include "motor.h"

struct motor_s {
    dc_motor_handle_t dc;
    encoder_handle_t enc;
    bool has_encoder;
    bool invert;
};

esp_err_t motor_init(motor_handle_t *out, const motor_cfg_t *cfg) {
    if (out == NULL || cfg == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    motor_handle_t m = calloc(1, sizeof(*m));
    if (m == NULL) {
        return ESP_ERR_NO_MEM;
    }
    m->has_encoder = cfg->has_encoder;
    m->invert = cfg->invert;

    esp_err_t err = dc_motor_init(&m->dc, &cfg->dc);
    if (err != ESP_OK) {
        free(m);
        return err;
    }

    if (cfg->has_encoder) {
        err = encoder_init(&m->enc, &cfg->enc);
        if (err != ESP_OK) {
            dc_motor_deinit(m->dc);
            free(m);
            return err;
        }
    }

    *out = m;
    return ESP_OK;
}

esp_err_t motor_set_duty(motor_handle_t m, float duty) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    return dc_motor_set_duty(m->dc, m->invert ? -duty : duty);
}

esp_err_t motor_stop(motor_handle_t m) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    return dc_motor_stop(m->dc);
}

esp_err_t motor_brake(motor_handle_t m) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    return dc_motor_brake(m->dc);
}

esp_err_t motor_read_counts(motor_handle_t m, int32_t *counts) {
    if (m == NULL || counts == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    if (!m->has_encoder) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    esp_err_t err = encoder_read_counts(m->enc, counts);
    if (err != ESP_OK) {
        return err;
    }
    if (m->invert) {
        *counts = -*counts;
    }
    return ESP_OK;
}

esp_err_t motor_reset_counts(motor_handle_t m) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    if (!m->has_encoder) {
        return ESP_ERR_NOT_SUPPORTED;
    }
    return encoder_reset_counts(m->enc);
}

esp_err_t motor_set_invert(motor_handle_t m, bool invert) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    m->invert = invert;
    return ESP_OK;
}

esp_err_t motor_deinit(motor_handle_t m) {
    if (m == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    if (m->has_encoder && m->enc != NULL) {
        encoder_deinit(m->enc);
    }
    if (m->dc != NULL) {
        dc_motor_deinit(m->dc);
    }
    free(m);
    return ESP_OK;
}
