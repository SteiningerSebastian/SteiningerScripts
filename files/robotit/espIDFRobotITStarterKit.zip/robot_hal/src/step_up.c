/*
 * Step-up (boost) converter driver for the RobotCar main board.
 *
 * The NOT_SLEEP pin (IO21) enables the boost converter that generates the
 * ~10V motor supply (VM). This driver only toggles that pin between its two
 * states - on (active) and off (sleep) - so callers can keep the converter
 * running while the H-bridge needs it and let it sleep when it doesn't.
 */
#include <stdbool.h>

#include "driver/gpio.h"
#include "esp_err.h"

#include "pinout.h"
#include "step_up.h"

esp_err_t step_up_init(void) {
    gpio_config_t cfg = {
        .pin_bit_mask = 1ULL << NOT_SLEEP,
        .mode = GPIO_MODE_OUTPUT,
    };
    esp_err_t err = gpio_config(&cfg);
    if (err == ESP_OK) {
        gpio_set_level(NOT_SLEEP, 0);
    }
    return err;
}

void step_up_set(bool on) {
    gpio_set_level(NOT_SLEEP, on);
}

void step_up_on(void) {
    step_up_set(true);
}

void step_up_off(void) {
    step_up_set(false);
}
