/*
 * Persistent key-value string store backed by NVS flash.
 *
 * Wraps the ESP-IDF NVS API to store string values keyed by name. Values
 * are committed to flash on write so they survive power cycles.
 */
#include <string.h>

#include "nvs.h"
#include "nvs_flash.h"
#include "esp_err.h"

#include "kv_store.h"

#define KV_STORE_NAMESPACE "kv_store"

static nvs_handle_t s_handle;
static bool s_initialised = false;

esp_err_t kv_store_init(void) {
    /* Initialise NVS flash if it hasn't been done yet. */
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        /* NVS partition was truncated / needs a fresh start. */
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    if (err != ESP_OK) {
        return err;
    }

    err = nvs_open(KV_STORE_NAMESPACE, NVS_READWRITE, &s_handle);
    if (err != ESP_OK) {
        return err;
    }
    s_initialised = true;
    return ESP_OK;
}

esp_err_t kv_store_set(const char *key, const char *value) {
    if (!s_initialised || key == NULL || value == NULL) {
        return ESP_ERR_INVALID_STATE;
    }
    if (strlen(key) > KV_STORE_MAX_KEY_LEN) {
        return ESP_ERR_INVALID_ARG;
    }

    esp_err_t err = nvs_set_str(s_handle, key, value);
    if (err != ESP_OK) {
        return err;
    }
    return nvs_commit(s_handle);
}

esp_err_t kv_store_get(const char *key, char *out_buf, size_t buf_size) {
    if (!s_initialised || key == NULL || out_buf == NULL || buf_size == 0) {
        return ESP_ERR_INVALID_STATE;
    }

    size_t len = buf_size;
    esp_err_t err = nvs_get_str(s_handle, key, out_buf, &len);
    if (err == ESP_ERR_NVS_NOT_FOUND) {
        return err;
    }
    if (err == ESP_OK && len > buf_size) {
        return ESP_ERR_NVS_INVALID_LENGTH;
    }
    return err;
}

esp_err_t kv_store_erase(const char *key) {
    if (!s_initialised || key == NULL) {
        return ESP_ERR_INVALID_STATE;
    }
    esp_err_t err = nvs_erase_key(s_handle, key);
    if (err != ESP_OK) {
        return err;
    }
    return nvs_commit(s_handle);
}

esp_err_t kv_store_erase_all(void) {
    if (!s_initialised) {
        return ESP_ERR_INVALID_STATE;
    }
    esp_err_t err = nvs_erase_all(s_handle);
    if (err != ESP_OK) {
        return err;
    }
    return nvs_commit(s_handle);
}
