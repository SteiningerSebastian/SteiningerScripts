idf_component_register(
    SRCS "src/status_led.c" "src/buzzer.c" "src/step_up.c" "src/dc_motor.c" "src/encoder.c" "src/motor.c" "src/battery.c" "src/vl53l0x.c" "src/sensor_array.c" "src/kv_store.c" "src/boot_button.c"
    INCLUDE_DIRS "include"
    REQUIRES esp_driver_gpio esp_driver_ledc esp_driver_mcpwm esp_driver_i2c esp_adc nvs_flash
    PRIV_REQUIRES esp_driver_pcnt esp_timer freertos
)